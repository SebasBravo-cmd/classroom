import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import '../styles/Registrar.css';

const Registrar = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('estudiante');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      localStorage.setItem(email, JSON.stringify({ password, role }));
      setMessage('Usuario registrado exitosamente');
      // Limpia el formulario
      setEmail('');
      setPassword('');
      setRole('estudiante');
      // Redirige al login después de 2 segundos
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } catch (error) {
      setMessage('Error al registrar usuario');
    }
  };

  return (
    <div className="register-container">
      <form onSubmit={handleSubmit} className="register-form">
        <h2>Registrar Usuario</h2>
        
        {message && <div className="message">{message}</div>}
        
        <div className="form-group">
          <input
            type="email"
            placeholder="Correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>


        <div className="form-group">
          <select 
            value={role} 
            onChange={(e) => setRole(e.target.value)}
            className="role-select"
          >
            <option value="estudiante">Estudiante</option>
            <option value="profesor">Profesor</option>
            <option value="cliente">Cliente</option>
          </select>
        </div>

        <button type="submit">Registrar</button>

        <Link to="/" className="toggle-button">
          ¿Ya tienes cuenta? Inicia sesión
        </Link>
      </form>
    </div>
  );
};

export default Registrar;
