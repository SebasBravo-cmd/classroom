import React from 'react';
import '../../styles/components/ProfesorDashboard.css';

const BienvenidaProfesor = () => {
  const fecha = new Date().toLocaleDateString('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const estadisticas = {
    estudiantesActivos: 150,
    cursosActivos: 4,
    tareasPorRevisar: 25,
    mensajesNoLeidos: 8
  };

  const proximasClases = [
    {
      titulo: 'Introducción a React',
      curso: 'Desarrollo Web',
      hora: '10:00',
      duracion: '2 horas',
      estudiantes: 25
    },
    {
      titulo: 'Principios de UX',
      curso: 'Diseño UX',
      hora: '15:00',
      duracion: '1.5 horas',
      estudiantes: 20
    }
  ];

  return (
    <div className="dashboard-container">
      <div className="welcome-header">
        <h1>¡Bienvenido, Profesor!</h1>
        <span className="date-display">{fecha}</span>
      </div>

      <button className="action-button">
        <i className="fas fa-video"></i> Iniciar Clase Virtual
      </button>

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Estudiantes Activos</h3>
          <div className="number">{estadisticas.estudiantesActivos}</div>
        </div>
        <div className="stat-card">
          <h3>Cursos Activos</h3>
          <div className="number">{estadisticas.cursosActivos}</div>
        </div>
        <div className="stat-card">
          <h3>Tareas por Revisar</h3>
          <div className="number">{estadisticas.tareasPorRevisar}</div>
        </div>
        <div className="stat-card">
          <h3>Mensajes No Leídos</h3>
          <div className="number">{estadisticas.mensajesNoLeidos}</div>
        </div>
      </div>

      <div className="upcoming-classes">
        <h2>Próximas Clases</h2>
        {proximasClases.map((clase, index) => (
          <div key={index} className="class-item">
            <div className="class-header">
              <div className="class-title">{clase.titulo}</div>
              <button className="class-action">Preparar Clase</button>
            </div>
            <div className="class-meta">
              <span><i className="far fa-clock"></i> {clase.hora}</span>
              <span><i className="fas fa-hourglass-half"></i> {clase.duracion}</span>
              <span><i className="fas fa-users"></i> {clase.estudiantes} estudiantes</span>
            </div>
          </div>
        ))}
      </div>

      <div className="recent-activity">
        <h2>Actividad Reciente</h2>
        <div className="activity-item">
          <div className="activity-icon">
            <i className="fas fa-file-alt"></i>
          </div>
          <div className="activity-content">
            <div>Juan Pérez entregó Proyecto Final</div>
            <div className="activity-meta">Desarrollo Web - 10/3/2024, 15:30:00</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BienvenidaProfesor; 