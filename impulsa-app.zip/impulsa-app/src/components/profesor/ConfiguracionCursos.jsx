import React, { useState, useEffect } from 'react';

const ConfiguracionCursos = () => {
  const [configuracion, setConfiguracion] = useState({
    general: {
      visibilidad: 'publico',
      inscripcionAbierta: true,
      fechaInicio: '',
      fechaFin: '',
      capacidadMaxima: 30
    },
    evaluacion: {
      notaMinima: 60,
      intentosMaximos: 3,
      mostrarRetroalimentacion: true,
      permitirAutoevaluacion: false
    },
    notificaciones: {
      recordatoriosTareas: true,
      alertasCalificaciones: true,
      mensajesNuevos: true,
      frecuenciaRecordatorios: 'diaria'
    },
    permisos: {
      permitirDiscusiones: true,
      permitirMensajesPrivados: true,
      permitirEntregasTarde: false,
      requiereAprobacion: true
    }
  });

  const [cambiosPendientes, setCambiosPendientes] = useState(false);

  const handleChange = (seccion, campo, valor) => {
    setConfiguracion(prev => ({
      ...prev,
      [seccion]: {
        ...prev[seccion],
        [campo]: valor
      }
    }));
    setCambiosPendientes(true);
  };

  const guardarCambios = async () => {
    try {
      // Aquí iría la lógica para guardar en la base de datos
      console.log('Guardando configuración:', configuracion);
      setCambiosPendientes(false);
      // Mostrar mensaje de éxito
    } catch (error) {
      console.error('Error al guardar:', error);
      // Mostrar mensaje de error
    }
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <h2>Configuración del Curso</h2>
        {cambiosPendientes && (
          <div className="cambios-pendientes">
            <span>Tienes cambios sin guardar</span>
            <button 
              className="btn-primary"
              onClick={guardarCambios}
            >
              Guardar Cambios
            </button>
          </div>
        )}
      </div>

      <div className="configuracion-grid">
        {/* Configuración General */}
        <div className="config-section">
          <h3>Configuración General</h3>
          <div className="form-group">
            <label>Visibilidad del Curso</label>
            <select
              value={configuracion.general.visibilidad}
              onChange={(e) => handleChange('general', 'visibilidad', e.target.value)}
            >
              <option value="publico">Público</option>
              <option value="privado">Privado</option>
              <option value="invitacion">Solo por invitación</option>
            </select>
          </div>

          <div className="form-group">
            <label>
              <input
                type="checkbox"
                checked={configuracion.general.inscripcionAbierta}
                onChange={(e) => handleChange('general', 'inscripcionAbierta', e.target.checked)}
              />
              Permitir nuevas inscripciones
            </label>
          </div>

          <div className="form-group">
            <label>Fecha de Inicio</label>
            <input
              type="date"
              value={configuracion.general.fechaInicio}
              onChange={(e) => handleChange('general', 'fechaInicio', e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Capacidad Máxima</label>
            <input
              type="number"
              value={configuracion.general.capacidadMaxima}
              onChange={(e) => handleChange('general', 'capacidadMaxima', parseInt(e.target.value))}
            />
          </div>
        </div>

        {/* Configuración de Evaluación */}
        <div className="config-section">
          <h3>Evaluación</h3>
          <div className="form-group">
            <label>Nota Mínima de Aprobación</label>
            <input
              type="number"
              value={configuracion.evaluacion.notaMinima}
              onChange={(e) => handleChange('evaluacion', 'notaMinima', parseInt(e.target.value))}
            />
          </div>

          <div className="form-group">
            <label>Intentos Máximos</label>
            <input
              type="number"
              value={configuracion.evaluacion.intentosMaximos}
              onChange={(e) => handleChange('evaluacion', 'intentosMaximos', parseInt(e.target.value))}
            />
          </div>

          <div className="form-group">
            <label>
              <input
                type="checkbox"
                checked={configuracion.evaluacion.mostrarRetroalimentacion}
                onChange={(e) => handleChange('evaluacion', 'mostrarRetroalimentacion', e.target.checked)}
              />
              Mostrar retroalimentación inmediata
            </label>
          </div>
        </div>

        {/* Configuración de Notificaciones */}
        <div className="config-section">
          <h3>Notificaciones</h3>
          <div className="form-group">
            <label>
              <input
                type="checkbox"
                checked={configuracion.notificaciones.recordatoriosTareas}
                onChange={(e) => handleChange('notificaciones', 'recordatoriosTareas', e.target.checked)}
              />
              Enviar recordatorios de tareas
            </label>
          </div>

          <div className="form-group">
            <label>Frecuencia de Recordatorios</label>
            <select
              value={configuracion.notificaciones.frecuenciaRecordatorios}
              onChange={(e) => handleChange('notificaciones', 'frecuenciaRecordatorios', e.target.value)}
            >
              <option value="diaria">Diaria</option>
              <option value="semanal">Semanal</option>
              <option value="quincenal">Quincenal</option>
            </select>
          </div>
        </div>

        {/* Configuración de Permisos */}
        <div className="config-section">
          <h3>Permisos y Restricciones</h3>
          <div className="form-group">
            <label>
              <input
                type="checkbox"
                checked={configuracion.permisos.permitirDiscusiones}
                onChange={(e) => handleChange('permisos', 'permitirDiscusiones', e.target.checked)}
              />
              Permitir foros de discusión
            </label>
          </div>

          <div className="form-group">
            <label>
              <input
                type="checkbox"
                checked={configuracion.permisos.permitirEntregasTarde}
                onChange={(e) => handleChange('permisos', 'permitirEntregasTarde', e.target.checked)}
              />
              Permitir entregas tardías
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfiguracionCursos; 