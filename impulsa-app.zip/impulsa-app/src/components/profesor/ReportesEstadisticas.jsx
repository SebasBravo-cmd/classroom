import React, { useState, useEffect } from 'react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';

const ReportesEstadisticas = () => {
  const [estadisticas, setEstadisticas] = useState({
    rendimiento: [],
    participacion: {},
    calificaciones: {},
    asistencia: []
  });

  const [periodoSeleccionado, setPeriodoSeleccionado] = useState('mes');
  const [cursoSeleccionado, setCursoSeleccionado] = useState('todos');

  useEffect(() => {
    // Simular carga de datos estadísticos
    const datosDemo = {
      rendimiento: [
        { fecha: '2024-01', promedio: 85 },
        { fecha: '2024-02', promedio: 88 },
        { fecha: '2024-03', promedio: 82 }
      ],
      participacion: {
        foros: 45,
        tareas: 78,
        examenes: 92,
        proyectos: 65
      },
      calificaciones: {
        'A': 25,
        'B': 35,
        'C': 20,
        'D': 15,
        'F': 5
      },
      asistencia: [
        { semana: 1, porcentaje: 95 },
        { semana: 2, porcentaje: 88 },
        { semana: 3, porcentaje: 92 }
      ]
    };

    setEstadisticas(datosDemo);
  }, [periodoSeleccionado, cursoSeleccionado]);

  const dataRendimiento = {
    labels: estadisticas.rendimiento.map(item => item.fecha),
    datasets: [{
      label: 'Rendimiento Promedio',
      data: estadisticas.rendimiento.map(item => item.promedio),
      borderColor: '#4b186f',
      tension: 0.4
    }]
  };

  const dataParticipacion = {
    labels: Object.keys(estadisticas.participacion),
    datasets: [{
      data: Object.values(estadisticas.participacion),
      backgroundColor: [
        '#4b186f',
        '#6b5b95',
        '#84b6f4',
        '#fdcb6e'
      ]
    }]
  };

  const dataCalificaciones = {
    labels: Object.keys(estadisticas.calificaciones),
    datasets: [{
      label: 'Distribución de Calificaciones',
      data: Object.values(estadisticas.calificaciones),
      backgroundColor: '#4b186f'
    }]
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <h2>Reportes y Estadísticas</h2>
        <div className="filtros-reportes">
          <select
            value={periodoSeleccionado}
            onChange={(e) => setPeriodoSeleccionado(e.target.value)}
          >
            <option value="semana">Última Semana</option>
            <option value="mes">Último Mes</option>
            <option value="trimestre">Último Trimestre</option>
          </select>
          <select
            value={cursoSeleccionado}
            onChange={(e) => setCursoSeleccionado(e.target.value)}
          >
            <option value="todos">Todos los Cursos</option>
            <option value="curso1">Curso 1</option>
            <option value="curso2">Curso 2</option>
          </select>
        </div>
      </div>

      <div className="estadisticas-grid">
        <div className="chart-container">
          <h3>Rendimiento a lo largo del tiempo</h3>
          <Line data={dataRendimiento} options={{
            responsive: true,
            maintainAspectRatio: false
          }} />
        </div>

        <div className="chart-container">
          <h3>Participación por Actividad</h3>
          <Doughnut data={dataParticipacion} options={{
            responsive: true,
            maintainAspectRatio: false
          }} />
        </div>

        <div className="chart-container">
          <h3>Distribución de Calificaciones</h3>
          <Bar data={dataCalificaciones} options={{
            responsive: true,
            maintainAspectRatio: false
          }} />
        </div>

        <div className="metricas-resumen">
          <div className="metrica-card">
            <h4>Promedio General</h4>
            <span className="valor">85%</span>
          </div>
          <div className="metrica-card">
            <h4>Tasa de Aprobación</h4>
            <span className="valor">92%</span>
          </div>
          <div className="metrica-card">
            <h4>Participación Activa</h4>
            <span className="valor">78%</span>
          </div>
        </div>
      </div>

      <div className="acciones-reportes">
        <button className="btn-primary">
          <i className="fas fa-download"></i> Exportar Reporte
        </button>
        <button className="btn-secondary">
          <i className="fas fa-envelope"></i> Enviar por Email
        </button>
      </div>
    </div>
  );
};

export default ReportesEstadisticas; 