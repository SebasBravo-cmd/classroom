import React, { useState, useEffect } from 'react';

const GestionCursos = () => {
  const [cursos, setCursos] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [nuevoCurso, setNuevoCurso] = useState({
    titulo: '',
    descripcion: '',
    categoria: '',
    nivel: 'principiante',
    duracion: '',
    precio: ''
  });

  useEffect(() => {
    // Simular carga de cursos
    const cursosDemo = [
      {
        id: 1,
        titulo: 'Desarrollo Web Avanzado',
        descripcion: 'Curso completo de desarrollo web moderno',
        categoria: 'Programación',
        nivel: 'avanzado',
        estudiantes: 45,
        calificacion: 4.8,
        estado: 'activo'
      },
      {
        id: 2,
        titulo: 'Diseño UX/UI',
        descripcion: 'Fundamentos del diseño de experiencia de usuario',
        categoria: 'Diseño',
        nivel: 'intermedio',
        estudiantes: 32,
        calificacion: 4.5,
        estado: 'borrador'
      }
    ];
    setCursos(cursosDemo);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aquí iría la lógica para crear/actualizar curso
    console.log('Nuevo curso:', nuevoCurso);
    setModalVisible(false);
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <h2>Gestión de Cursos</h2>
        <button 
          className="btn-primary"
          onClick={() => setModalVisible(true)}
        >
          <i className="fas fa-plus"></i> Nuevo Curso
        </button>
      </div>

      <div className="cursos-grid">
        {cursos.map(curso => (
          <div key={curso.id} className="curso-card">
            <div className="curso-header">
              <h3>{curso.titulo}</h3>
              <span className={`estado-badge ${curso.estado}`}>
                {curso.estado}
              </span>
            </div>
            
            <p className="curso-descripcion">{curso.descripcion}</p>
            
            <div className="curso-meta">
              <span>
                <i className="fas fa-users"></i>
                {curso.estudiantes} estudiantes
              </span>
              <span>
                <i className="fas fa-star"></i>
                {curso.calificacion}
              </span>
              <span>
                <i className="fas fa-layer-group"></i>
                {curso.nivel}
              </span>
            </div>

            <div className="curso-actions">
              <button className="btn-secondary">
                <i className="fas fa-edit"></i> Editar
              </button>
              <button className="btn-secondary">
                <i className="fas fa-cog"></i> Configurar
              </button>
              <button className="btn-danger">
                <i className="fas fa-trash"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {modalVisible && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Nuevo Curso</h3>
              <button 
                className="close-btn"
                onClick={() => setModalVisible(false)}
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Título del Curso</label>
                <input
                  type="text"
                  value={nuevoCurso.titulo}
                  onChange={(e) => setNuevoCurso({
                    ...nuevoCurso,
                    titulo: e.target.value
                  })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Descripción</label>
                <textarea
                  value={nuevoCurso.descripcion}
                  onChange={(e) => setNuevoCurso({
                    ...nuevoCurso,
                    descripcion: e.target.value
                  })}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Categoría</label>
                  <select
                    value={nuevoCurso.categoria}
                    onChange={(e) => setNuevoCurso({
                      ...nuevoCurso,
                      categoria: e.target.value
                    })}
                    required
                  >
                    <option value="">Seleccionar categoría</option>
                    <option value="programacion">Programación</option>
                    <option value="diseno">Diseño</option>
                    <option value="marketing">Marketing</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Nivel</label>
                  <select
                    value={nuevoCurso.nivel}
                    onChange={(e) => setNuevoCurso({
                      ...nuevoCurso,
                      nivel: e.target.value
                    })}
                    required
                  >
                    <option value="principiante">Principiante</option>
                    <option value="intermedio">Intermedio</option>
                    <option value="avanzado">Avanzado</option>
                  </select>
                </div>
              </div>

              <div className="modal-actions">
                <button type="submit" className="btn-primary">
                  Crear Curso
                </button>
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => setModalVisible(false)}
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default GestionCursos; 