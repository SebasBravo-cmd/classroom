import React, { useState, useEffect } from 'react';

const GestionEstudiantes = () => {
  const [estudiantes, setEstudiantes] = useState([]);
  const [filtro, setFiltro] = useState('');
  const [ordenarPor, setOrdenarPor] = useState('nombre');
  const [modalVisible, setModalVisible] = useState(false);
  const [estudianteSeleccionado, setEstudianteSeleccionado] = useState(null);

  useEffect(() => {
    // Simular carga de estudiantes
    const estudiantesDemo = [
      {
        id: 1,
        nombre: 'Ana García',
        email: 'ana@ejemplo.com',
        progreso: 75,
        ultimaActividad: '2024-03-10',
        estado: 'activo'
      },
      {
        id: 2,
        nombre: 'Carlos López',
        email: 'carlos@ejemplo.com',
        progreso: 45,
        ultimaActividad: '2024-03-08',
        estado: 'inactivo'
      }
    ];
    setEstudiantes(estudiantesDemo);
  }, []);

  const filtrarEstudiantes = () => {
    return estudiantes
      .filter(est => 
        est.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
        est.email.toLowerCase().includes(filtro.toLowerCase())
      )
      .sort((a, b) => {
        if (ordenarPor === 'nombre') {
          return a.nombre.localeCompare(b.nombre);
        } else if (ordenarPor === 'progreso') {
          return b.progreso - a.progreso;
        }
        return 0;
      });
  };

  const verDetallesEstudiante = (estudiante) => {
    setEstudianteSeleccionado(estudiante);
    setModalVisible(true);
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <h2>Gestión de Estudiantes</h2>
        <div className="header-actions">
          <div className="search-box">
            <i className="fas fa-search"></i>
            <input
              type="text"
              placeholder="Buscar estudiantes..."
              value={filtro}
              onChange={(e) => setFiltro(e.target.value)}
            />
          </div>
          <select
            value={ordenarPor}
            onChange={(e) => setOrdenarPor(e.target.value)}
            className="sort-select"
          >
            <option value="nombre">Ordenar por nombre</option>
            <option value="progreso">Ordenar por progreso</option>
          </select>
          <button className="btn-primary">
            <i className="fas fa-plus"></i> Agregar Estudiante
          </button>
        </div>
      </div>

      <div className="estudiantes-grid">
        {filtrarEstudiantes().map(estudiante => (
          <div key={estudiante.id} className="estudiante-card">
            <div className="estudiante-header">
              <div className="estudiante-avatar">
                <i className="fas fa-user"></i>
              </div>
              <div className="estudiante-info">
                <h3>{estudiante.nombre}</h3>
                <p>{estudiante.email}</p>
              </div>
              <span className={`estado-badge ${estudiante.estado}`}>
                {estudiante.estado}
              </span>
            </div>
            
            <div className="estudiante-stats">
              <div className="stat-item">
                <span>Progreso</span>
                <div className="progress-bar">
                  <div 
                    className="progress-fill"
                    style={{ width: `${estudiante.progreso}%` }}
                  />
                </div>
                <span>{estudiante.progreso}%</span>
              </div>
              <div className="stat-item">
                <span>Última actividad</span>
                <p>{new Date(estudiante.ultimaActividad).toLocaleDateString()}</p>
              </div>
            </div>

            <div className="estudiante-actions">
              <button 
                className="btn-secondary"
                onClick={() => verDetallesEstudiante(estudiante)}
              >
                Ver Detalles
              </button>
              <button className="btn-icon">
                <i className="fas fa-envelope"></i>
              </button>
              <button className="btn-icon">
                <i className="fas fa-cog"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {modalVisible && estudianteSeleccionado && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Detalles del Estudiante</h3>
              <button 
                className="close-btn"
                onClick={() => setModalVisible(false)}
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="modal-body">
              {/* Aquí va el contenido detallado del estudiante */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GestionEstudiantes; 