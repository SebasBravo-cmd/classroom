import React, { useState, useEffect } from 'react';

const ComunicacionProfesor = () => {
  const [mensajes, setMensajes] = useState([]);
  const [anuncios, setAnuncios] = useState([]);
  const [nuevoAnuncio, setNuevoAnuncio] = useState({
    titulo: '',
    contenido: '',
    cursos: [],
    prioridad: 'normal'
  });
  const [modalAnuncio, setModalAnuncio] = useState(false);
  const [cursos, setCursos] = useState([]);
  const [filtroMensajes, setFiltroMensajes] = useState('todos');

  useEffect(() => {
    // Simular carga de datos
    const mensajesDemo = [
      {
        id: 1,
        remitente: 'Juan Pérez',
        asunto: 'Consulta sobre proyecto final',
        contenido: 'Profesor, tengo una duda sobre...',
        fecha: '2024-03-10T14:30:00',
        leido: false,
        curso: 'Desarrollo Web'
      },
      {
        id: 2,
        remitente: 'María García',
        asunto: 'Solicitud de extensión',
        contenido: 'Debido a problemas técnicos...',
        fecha: '2024-03-09T16:45:00',
        leido: true,
        curso: 'Diseño UX'
      }
    ];

    const anunciosDemo = [
      {
        id: 1,
        titulo: 'Cambio en fecha de entrega',
        contenido: 'La entrega del proyecto se extenderá...',
        fecha: '2024-03-08',
        cursos: ['Desarrollo Web'],
        prioridad: 'alta'
      }
    ];

    const cursosDemo = [
      { id: 1, nombre: 'Desarrollo Web' },
      { id: 2, nombre: 'Diseño UX' }
    ];

    setMensajes(mensajesDemo);
    setAnuncios(anunciosDemo);
    setCursos(cursosDemo);
  }, []);

  const publicarAnuncio = (e) => {
    e.preventDefault();
    const nuevoAnuncioObj = {
      id: Date.now(),
      ...nuevoAnuncio,
      fecha: new Date().toISOString()
    };
    setAnuncios([nuevoAnuncioObj, ...anuncios]);
    setModalAnuncio(false);
    setNuevoAnuncio({
      titulo: '',
      contenido: '',
      cursos: [],
      prioridad: 'normal'
    });
  };

  const marcarComoLeido = (mensajeId) => {
    setMensajes(mensajes.map(msg => 
      msg.id === mensajeId ? {...msg, leido: true} : msg
    ));
  };

  return (
    <div className="section-container">
      <div className="comunicacion-header">
        <h2>Comunicación</h2>
        <button 
          className="btn-primary"
          onClick={() => setModalAnuncio(true)}
        >
          <i className="fas fa-bullhorn"></i> Nuevo Anuncio
        </button>
      </div>

      <div className="comunicacion-grid">
        {/* Panel de Mensajes */}
        <div className="mensajes-panel">
          <div className="panel-header">
            <h3>Mensajes Recibidos</h3>
            <select
              value={filtroMensajes}
              onChange={(e) => setFiltroMensajes(e.target.value)}
            >
              <option value="todos">Todos</option>
              <option value="no-leidos">No leídos</option>
              <option value="leidos">Leídos</option>
            </select>
          </div>

          <div className="mensajes-lista">
            {mensajes
              .filter(msg => {
                if (filtroMensajes === 'no-leidos') return !msg.leido;
                if (filtroMensajes === 'leidos') return msg.leido;
                return true;
              })
              .map(mensaje => (
                <div 
                  key={mensaje.id} 
                  className={`mensaje-card ${!mensaje.leido ? 'no-leido' : ''}`}
                  onClick={() => marcarComoLeido(mensaje.id)}
                >
                  <div className="mensaje-info">
                    <h4>{mensaje.remitente}</h4>
                    <span className="curso-badge">{mensaje.curso}</span>
                  </div>
                  <p className="mensaje-asunto">{mensaje.asunto}</p>
                  <p className="mensaje-preview">{mensaje.contenido}</p>
                  <div className="mensaje-footer">
                    <span>{new Date(mensaje.fecha).toLocaleString()}</span>
                    <div className="mensaje-acciones">
                      <button className="btn-icon">
                        <i className="fas fa-reply"></i>
                      </button>
                      <button className="btn-icon">
                        <i className="fas fa-archive"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Panel de Anuncios */}
        <div className="anuncios-panel">
          <h3>Anuncios Publicados</h3>
          <div className="anuncios-lista">
            {anuncios.map(anuncio => (
              <div 
                key={anuncio.id} 
                className={`anuncio-card prioridad-${anuncio.prioridad}`}
              >
                <div className="anuncio-header">
                  <h4>{anuncio.titulo}</h4>
                  <span className="prioridad-badge">
                    {anuncio.prioridad}
                  </span>
                </div>
                <p>{anuncio.contenido}</p>
                <div className="anuncio-footer">
                  <div className="cursos-tags">
                    {anuncio.cursos.map(curso => (
                      <span key={curso} className="curso-tag">
                        {curso}
                      </span>
                    ))}
                  </div>
                  <span>{new Date(anuncio.fecha).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {modalAnuncio && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Nuevo Anuncio</h3>
              <button 
                className="close-btn"
                onClick={() => setModalAnuncio(false)}
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <form onSubmit={publicarAnuncio}>
              <div className="form-group">
                <label>Título</label>
                <input
                  type="text"
                  value={nuevoAnuncio.titulo}
                  onChange={(e) => setNuevoAnuncio({
                    ...nuevoAnuncio,
                    titulo: e.target.value
                  })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Contenido</label>
                <textarea
                  value={nuevoAnuncio.contenido}
                  onChange={(e) => setNuevoAnuncio({
                    ...nuevoAnuncio,
                    contenido: e.target.value
                  })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Cursos</label>
                <select
                  multiple
                  value={nuevoAnuncio.cursos}
                  onChange={(e) => setNuevoAnuncio({
                    ...nuevoAnuncio,
                    cursos: Array.from(e.target.selectedOptions, option => option.value)
                  })}
                >
                  {cursos.map(curso => (
                    <option key={curso.id} value={curso.nombre}>
                      {curso.nombre}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>Prioridad</label>
                <select
                  value={nuevoAnuncio.prioridad}
                  onChange={(e) => setNuevoAnuncio({
                    ...nuevoAnuncio,
                    prioridad: e.target.value
                  })}
                >
                  <option value="baja">Baja</option>
                  <option value="normal">Normal</option>
                  <option value="alta">Alta</option>
                </select>
              </div>

              <div className="modal-actions">
                <button type="submit" className="btn-primary">
                  Publicar Anuncio
                </button>
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => setModalAnuncio(false)}
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComunicacionProfesor; 