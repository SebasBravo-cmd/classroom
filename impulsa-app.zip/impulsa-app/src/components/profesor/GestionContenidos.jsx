import React, { useState, useEffect } from 'react';

const GestionContenidos = () => {
  const [contenidos, setContenidos] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [nuevoContenido, setNuevoContenido] = useState({
    titulo: '',
    tipo: 'documento',
    archivo: null,
    descripcion: '',
    fechaPublicacion: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Aquí iría la lógica para subir el contenido
      const formData = new FormData();
      formData.append('titulo', nuevoContenido.titulo);
      formData.append('tipo', nuevoContenido.tipo);
      formData.append('archivo', nuevoContenido.archivo);
      formData.append('descripcion', nuevoContenido.descripcion);
      formData.append('fechaPublicacion', nuevoContenido.fechaPublicacion);

      // Simular subida
      console.log('Subiendo contenido:', formData);
      
      setModalVisible(false);
      setNuevoContenido({
        titulo: '',
        tipo: 'documento',
        archivo: null,
        descripcion: '',
        fechaPublicacion: ''
      });
    } catch (error) {
      console.error('Error al subir contenido:', error);
    }
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <h2>Gestión de Contenidos</h2>
        <button 
          className="btn-primary"
          onClick={() => setModalVisible(true)}
        >
          <i className="fas fa-plus"></i> Nuevo Contenido
        </button>
      </div>

      {modalVisible && (
        <div className="modal">
          <div className="modal-content">
            <h3>Subir Nuevo Contenido</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Título</label>
                <input
                  type="text"
                  value={nuevoContenido.titulo}
                  onChange={(e) => setNuevoContenido({
                    ...nuevoContenido,
                    titulo: e.target.value
                  })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Tipo de Contenido</label>
                <select
                  value={nuevoContenido.tipo}
                  onChange={(e) => setNuevoContenido({
                    ...nuevoContenido,
                    tipo: e.target.value
                  })}
                >
                  <option value="documento">Documento</option>
                  <option value="video">Video</option>
                  <option value="presentacion">Presentación</option>
                </select>
              </div>

              <div className="form-group">
                <label>Archivo</label>
                <input
                  type="file"
                  onChange={(e) => setNuevoContenido({
                    ...nuevoContenido,
                    archivo: e.target.files[0]
                  })}
                  required
                />
              </div>

              <div className="form-group">
                <label>Descripción</label>
                <textarea
                  value={nuevoContenido.descripcion}
                  onChange={(e) => setNuevoContenido({
                    ...nuevoContenido,
                    descripcion: e.target.value
                  })}
                />
              </div>

              <div className="form-group">
                <label>Fecha de Publicación</label>
                <input
                  type="datetime-local"
                  value={nuevoContenido.fechaPublicacion}
                  onChange={(e) => setNuevoContenido({
                    ...nuevoContenido,
                    fechaPublicacion: e.target.value
                  })}
                />
              </div>

              <div className="modal-actions">
                <button type="submit" className="btn-primary">
                  Subir Contenido
                </button>
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => setModalVisible(false)}
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="content-list">
        {contenidos.map(contenido => (
          <div key={contenido.id} className="content-item">
            <div className="content-info">
              <h3>{contenido.titulo}</h3>
              <p>{contenido.descripcion}</p>
              <span className="content-meta">
                Publicado: {new Date(contenido.fechaPublicacion).toLocaleDateString()}
              </span>
            </div>
            <div className="content-actions">
              <button className="btn-icon">
                <i className="fas fa-edit"></i>
              </button>
              <button className="btn-icon">
                <i className="fas fa-trash"></i>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GestionContenidos; 