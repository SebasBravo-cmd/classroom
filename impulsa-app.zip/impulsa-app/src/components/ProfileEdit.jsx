import React, { useState, useEffect } from 'react';

const ProfileEdit = ({ userEmail }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [userData, setUserData] = useState({
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    direccion: '',
    biografia: '',
    avatar: ''
  });

  const [analytics, setAnalytics] = useState({
    revenue: '$0.00',
    orders: 0,
    courses: 1,
    students: 3,
    reviews: 0,
    certificates: 0
  });

  useEffect(() => {
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const currentUser = users.find(user => user.email === userEmail);
    if (currentUser) {
      setUserData({
        ...userData,
        ...currentUser
      });
    }
  }, [userEmail]);

  const handleChange = (e) => {
    setUserData({
      ...userData,
      [e.target.name]: e.target.value
    });
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUserData({
          ...userData,
          avatar: reader.result
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Lógica para guardar cambios
  };

  return (
    <div className="profile-section">
      <div className="profile-header">
        <div className="profile-avatar-section">
          {userData.avatar ? (
            <img src={userData.avatar} alt="Profile" className="profile-img" />
          ) : (
            <div className="avatar-placeholder">
              <i className="fas fa-user"></i>
            </div>
          )}
          <div className="avatar-upload">
            <input
              type="file"
              id="avatar-upload"
              accept="image/*"
              onChange={handleAvatarChange}
              className="avatar-input"
            />
            <label htmlFor="avatar-upload" className="avatar-upload-btn">
              {userData.avatar ? 'Cambiar foto' : 'Subir foto'}
            </label>
          </div>
        </div>
        <div className="profile-tabs">
          <button 
            className={`tab-btn ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            <i className="fas fa-user"></i> Perfil
          </button>
          <button 
            className={`tab-btn ${activeTab === 'analytics' ? 'active' : ''}`}
            onClick={() => setActiveTab('analytics')}
          >
            <i className="fas fa-chart-line"></i> Analytics
          </button>
          <button 
            className={`tab-btn ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <i className="fas fa-cog"></i> Ajustes
          </button>
        </div>
      </div>

      <div className="profile-content">
        {activeTab === 'profile' && (
          <form onSubmit={handleSubmit} className="profile-form">
            <h2>Información del Perfil</h2>
            <div className="form-group">
              <input
                type="text"
                name="nombre"
                placeholder="Nombre"
                value={userData.nombre}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <input
                type="text"
                name="apellido"
                placeholder="Apellido"
                value={userData.apellido}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <textarea
                name="biografia"
                placeholder="Biografía"
                value={userData.biografia || ''}
                onChange={handleChange}
              />
            </div>
            <button type="submit" className="save-btn">Guardar Cambios</button>
          </form>
        )}

        {activeTab === 'analytics' && (
          <div className="analytics-section">
            <h2>Analytics</h2>
            <div className="analytics-grid">
              <div className="stat-card">
                <h3>Revenue</h3>
                <p>{analytics.revenue}</p>
              </div>
              <div className="stat-card">
                <h3>Orders</h3>
                <p>{analytics.orders}</p>
              </div>
              <div className="stat-card">
                <h3>Courses</h3>
                <p>{analytics.courses}</p>
              </div>
              <div className="stat-card">
                <h3>Students</h3>
                <p>{analytics.students}</p>
              </div>
              <div className="stat-card">
                <h3>Reviews</h3>
                <p>{analytics.reviews}</p>
              </div>
              <div className="stat-card">
                <h3>Certificates</h3>
                <p>{analytics.certificates}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="settings-section">
            <h2>Ajustes</h2>
            <div className="settings-options">
              <button className="settings-btn">
                <i className="fas fa-star"></i>
                Hacer Destacado
              </button>
              <button className="settings-btn">
                <i className="fas fa-edit"></i>
                Editar Curso
              </button>
              <button className="settings-btn">
                <i className="fas fa-trash"></i>
                Eliminar Curso
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileEdit; 