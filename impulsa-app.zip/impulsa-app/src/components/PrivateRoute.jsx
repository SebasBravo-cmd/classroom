import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ children }) => {
  const userRole = localStorage.getItem('userRole');
  const currentUser = localStorage.getItem('currentUser');
  
  console.log('PrivateRoute - userRole:', userRole);
  console.log('PrivateRoute - currentUser:', currentUser);

  if (!userRole || !currentUser) {
    console.log('Redirigiendo a login por falta de autenticación');
    return <Navigate to="/" />;
  }

  return children;
};

export default PrivateRoute; 