// StudentDashboard.jsx
import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import '../../styles/components/ProfesorDashboard.css';

const ProfesorDashboard = () => {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState('inicio');
  const [subSection, setSubSection] = useState('');
  const [showSubMenu, setShowSubMenu] = useState('');
  const [cursos, setCursos] = useState(() => {
    const cursosGuardados = localStorage.getItem('cursos');
    return cursosGuardados ? JSON.parse(cursosGuardados) : [];
  });
  const [showSubcategoria, setShowSubcategoria] = useState(false);

  const handleMenuClick = (section) => {
    if (showSubMenu === section) {
      setShowSubMenu('');
    } else {
      setShowSubMenu(section);
    }
    setCurrentSection(section);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
    navigate('/');
  };

  const crearNuevoCurso = (e) => {
    e.preventDefault();
    const nuevoCurso = {
      id: Date.now(),
      nombre: e.target.nombre.value,
      categoria: e.target.categoria.value,
      subcategoria: e.target.categoria.value === 'formacion_inicial' ? e.target.subcategoria.value : null,
      duracion: e.target.duracion.value,
      progreso: 0,
      estado: 'en_progreso',
      fecha: new Date().toLocaleDateString()
    };
    
    const cursosActualizados = [...cursos, nuevoCurso];
    setCursos(cursosActualizados);
    localStorage.setItem('cursos', JSON.stringify(cursosActualizados));
    setSubSection('');
  };

  const renderDashboardContent = () => {
    // Contenido principal según la sección y subsección
    switch(currentSection) {
      case 'inicio':
        return (
          <div className="dashboard-container">
            <div className="bienvenida-header">
              <div className="bienvenida-titulo">
                <h1>¡Bienvenido, Profesor!</h1>
                <span className="fecha-actual">
                  {new Date().toLocaleDateString()}
                </span>
              </div>
              <button className="btn-clase-virtual">
                <i className="fas fa-video"></i>
                Programar Sesión en Vivo
              </button>
            </div>

            <div className="estadisticas-grid">
              <div className="estadistica-card">
                <div className="estadistica-icono">
                  <i className="fas fa-users"></i>
                </div>
                <div className="estadistica-valor">150</div>
                <div className="estadistica-label">Estudiantes Activos</div>
              </div>
              <div className="estadistica-card">
                <div className="estadistica-icono">
                  <i className="fas fa-tasks"></i>
                </div>
                <div className="estadistica-valor">25</div>
                <div className="estadistica-label">Tareas por Revisar</div>
              </div>
              <div className="estadistica-card">
                <div className="estadistica-icono">
                  <i className="fas fa-comments"></i>
                </div>
                <div className="estadistica-valor">8</div>
                <div className="estadistica-label">Foros Activos</div>
              </div>
            </div>
          </div>
        );

      case 'cursos':
        switch(subSection) {
          case 'crear':
            return (
              <div className="dashboard-container">
                <h2>Información del Curso</h2>
                <form onSubmit={crearNuevoCurso} className="crear-curso-form">
                  <div className="form-group">
                    <label htmlFor="nombre">Nombre del curso</label>
                    <input 
                      type="text" 
                      id="nombre" 
                      name="nombre" 
                      className="form-control"
                      required
                      placeholder="Ingrese el nombre del curso"
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="categoria">Categoría</label>
                    <select 
                      id="categoria" 
                      name="categoria" 
                      className="form-control" 
                      required
                      onChange={(e) => {
                        if(e.target.value === 'formacion_inicial') {
                          setShowSubcategoria(true);
                        } else {
                          setShowSubcategoria(false);
                        }
                      }}
                    >
                      <option value="">Seleccionar categoría</option>
                      <option value="calidad">Calidad</option>
                      <option value="estudyo_puntos">Estudyo Puntos</option>
                      <option value="formacion_continua">Formación Continua</option>
                      <option value="formacion_inicial">Formación Inicial</option>
                      <option value="habilidades_transversales">Habilidades Transversales</option>
                    </select>
                  </div>

                  {showSubcategoria && (
                    <div className="form-group">
                      <label htmlFor="subcategoria">Subcategoría</label>
                      <select 
                        id="subcategoria" 
                        name="subcategoria" 
                        className="form-control" 
                        required
                      >
                        <option value="">Seleccionar subcategoría</option>
                        <option value="herramientas_gestion">Herramientas de Gestión</option>
                        <option value="produccion">Producción</option>
                        <option value="servicios">Servicios</option>
                      </select>
                    </div>
                  )}

                  <div className="form-group">
                    <label htmlFor="duracion">Duración Estimada</label>
                    <input 
                      type="text" 
                      id="duracion" 
                      name="duracion" 
                      className="form-control"
                      required
                      placeholder="Ej: 20 minutos"
                    />
                  </div>
                  
                  <div className="form-actions">
                    <button type="button" className="btn-secundario">
                      <i className="fas fa-times"></i>
                      Cancelar
                    </button>
                    <button type="submit" className="btn-accion">
                      <i className="fas fa-plus"></i>
                      Crear Curso
                    </button>
                  </div>
                </form>
              </div>
            );
          case 'programar':
            return (
              <div className="dashboard-container">
                <h2>Programar Actividades</h2>
                <div className="programacion-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-calendar-plus"></i>
                    Nueva Actividad
                  </button>
                  <div className="calendario-actividades">
                    {/* Calendario de actividades */}
                  </div>
                </div>
              </div>
            );
          case 'acceso':
            return (
              <div className="dashboard-container">
                <h2>Control de Acceso</h2>
                <div className="acceso-config">
                  <div className="config-opciones">
                    <label>
                      <input type="checkbox" />
                      Habilitar acceso por fecha
                    </label>
                    <label>
                      <input type="checkbox" />
                      Habilitar acceso por grupo
                    </label>
                  </div>
                </div>
              </div>
            );
          default:
            return (
              <div className="dashboard-container">
                <h2>Gestión de Cursos</h2>
                <p>Selecciona una opción del menú lateral</p>
              </div>
            );
        }

      case 'contenidos':
        switch(subSection) {
          case 'biblioteca':
            return (
              <div className="dashboard-container">
                <h2>Biblioteca de Recursos</h2>
                <div className="biblioteca-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-upload"></i>
                    Subir Recurso
                  </button>
                  <button className="btn-accion">
                    <i className="fas fa-folder-plus"></i>
                    Nueva Carpeta
                  </button>
                </div>
                <div className="recursos-lista">
                  {/* Lista de recursos */}
                </div>
              </div>
            );
          case 'evaluaciones':
            return (
              <div className="dashboard-container">
                <h2>Evaluaciones</h2>
                <div className="evaluaciones-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-plus"></i>
                    Nueva Evaluación
                  </button>
                  <button className="btn-accion">
                    <i className="fas fa-clock"></i>
                    Programar Evaluación
                  </button>
                </div>
              </div>
            );
          case 'foros':
            return (
              <div className="dashboard-container">
                <h2>Foros y Debates</h2>
                <div className="foros-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-plus"></i>
                    Nuevo Foro
                  </button>
                  <button className="btn-accion">
                    <i className="fas fa-comments"></i>
                    Moderar Debates
                  </button>
                </div>
              </div>
            );
          default:
            return (
              <div className="dashboard-container">
                <h2>Contenidos</h2>
                <p>Selecciona una opción del menú lateral</p>
              </div>
            );
        }

      case 'estudiantes':
        switch(subSection) {
          case 'calificaciones':
            return (
              <div className="dashboard-container">
                <h2>Calificaciones</h2>
                <div className="calificaciones-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-plus"></i>
                    Registrar Calificaciones
                  </button>
                  <button className="btn-accion">
                    <i className="fas fa-eye"></i>
                    Configurar Visibilidad
                  </button>
                </div>
              </div>
            );
          case 'reportes':
            return (
              <div className="dashboard-container">
                <h2>Reportes y Progreso</h2>
                <div className="reportes-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-chart-bar"></i>
                    Ver Reportes Individuales
                  </button>
                  <button className="btn-accion">
                    <i className="fas fa-users"></i>
                    Ver Reportes Grupales
                  </button>
                </div>
              </div>
            );
          case 'retroalimentacion':
            return (
              <div className="dashboard-container">
                <h2>Retroalimentación</h2>
                <div className="retroalimentacion-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-comment"></i>
                    Nueva Retroalimentación
                  </button>
                  <button className="btn-accion">
                    <i className="fas fa-history"></i>
                    Ver Historial
                  </button>
                </div>
              </div>
            );
          default:
            return (
              <div className="dashboard-container">
                <h2>Estudiantes</h2>
                <p>Selecciona una opción del menú lateral</p>
              </div>
            );
        }

      case 'configuracion':
        return (
          <div className="dashboard-container">
            <h2>Configuración</h2>
            <div className="config-grid">
              <div className="permisos-section">
                <h3>Gestión de Permisos</h3>
                <div className="permisos-acciones">
                  <button className="btn-accion">
                    <i className="fas fa-user-lock"></i>
                    Asignar Permisos
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="dashboard-layout">
      <div className="sidebar">
        <div className="logo">
          <h2>Profesor</h2>
        </div>
        <nav>
          <a 
            onClick={() => handleMenuClick('inicio')} 
            className={`nav-item ${currentSection === 'inicio' ? 'active' : ''}`}
          >
            <i className="fas fa-home"></i>
            <span>Inicio</span>
          </a>

          {/* Gestión de Cursos con submenú */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('cursos')} 
              className={`nav-item ${currentSection === 'cursos' ? 'active' : ''}`}
            >
              <i className="fas fa-book"></i>
              <span>Gestión de Cursos</span>
              <i className={`fas fa-chevron-${showSubMenu === 'cursos' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'cursos' && (
              <div className="submenu">
                <a onClick={() => setSubSection('crear')} className="submenu-item">
                  <i className="fas fa-plus-circle"></i>
                  <span>Crear/Duplicar Curso</span>
                </a>
                <a onClick={() => setSubSection('programar')} className="submenu-item">
                  <i className="fas fa-calendar-alt"></i>
                  <span>Programar Actividades</span>
                </a>
                <a onClick={() => setSubSection('acceso')} className="submenu-item">
                  <i className="fas fa-lock"></i>
                  <span>Control de Acceso</span>
                </a>
              </div>
            )}
          </div>

          {/* Contenidos con submenú */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('contenidos')} 
              className={`nav-item ${currentSection === 'contenidos' ? 'active' : ''}`}
            >
              <i className="fas fa-file-alt"></i>
              <span>Contenidos</span>
              <i className={`fas fa-chevron-${showSubMenu === 'contenidos' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'contenidos' && (
              <div className="submenu">
                <a onClick={() => setSubSection('biblioteca')} className="submenu-item">
                  <i className="fas fa-folder"></i>
                  <span>Biblioteca de Recursos</span>
                </a>
                <a onClick={() => setSubSection('evaluaciones')} className="submenu-item">
                  <i className="fas fa-tasks"></i>
                  <span>Evaluaciones</span>
                </a>
                <a onClick={() => setSubSection('foros')} className="submenu-item">
                  <i className="fas fa-comments"></i>
                  <span>Foros y Debates</span>
                </a>
              </div>
            )}
          </div>

          {/* Estudiantes con submenú */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('estudiantes')} 
              className={`nav-item ${currentSection === 'estudiantes' ? 'active' : ''}`}
            >
              <i className="fas fa-users"></i>
              <span>Estudiantes</span>
              <i className={`fas fa-chevron-${showSubMenu === 'estudiantes' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'estudiantes' && (
              <div className="submenu">
                <a onClick={() => setSubSection('calificaciones')} className="submenu-item">
                  <i className="fas fa-star"></i>
                  <span>Calificaciones</span>
                </a>
                <a onClick={() => setSubSection('reportes')} className="submenu-item">
                  <i className="fas fa-chart-bar"></i>
                  <span>Reportes y Progreso</span>
                </a>
                <a onClick={() => setSubSection('retroalimentacion')} className="submenu-item">
                  <i className="fas fa-comment-alt"></i>
                  <span>Retroalimentación</span>
                </a>
              </div>
            )}
          </div>

          <a 
            onClick={() => handleMenuClick('configuracion')} 
            className={`nav-item ${currentSection === 'configuracion' ? 'active' : ''}`}
          >
            <i className="fas fa-cog"></i>
            <span>Configuración</span>
          </a>

          <button onClick={handleLogout} className="logout-btn">
            <i className="fas fa-sign-out-alt"></i>
            <span>Cerrar Sesión</span>
          </button>
        </nav>
      </div>
      <div className="main-content">
        {renderDashboardContent()}
      </div>
    </div>
  );
};

export default ProfesorDashboard;