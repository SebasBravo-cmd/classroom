// StudentDashboard.jsx
import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import '../../styles/components/EstudianteDashboard.css';

const EstudianteDashboard = () => {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState('inicio');
  const [subSection, setSubSection] = useState('');
  const [showSubMenu, setShowSubMenu] = useState('');
  const [showStats, setShowStats] = useState(true);
  const [currentFilter, setCurrentFilter] = useState('todos');
  const [cursos] = useState([
    {
      id: 1,
      tipo: 'Formación Inicial',
      titulo: 'Introducción DTH',
      duracion: '20 minutos',
      progreso: 0,
      estado: 'en_progreso',
      fecha: 'octubre 4, 2024'
    },
    // Agrega más cursos aquí para probar los filtros
  ]);

  const handleMenuClick = (section) => {
    if (showSubMenu === section) {
      setShowSubMenu('');
    } else {
      setShowSubMenu(section);
    }
    setCurrentSection(section);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
    navigate('/');
  };

  const filtrarCursos = () => {
    if (currentFilter === 'todos') return cursos;
    return cursos.filter(curso => curso.estado === currentFilter);
  };

  const renderDashboardContent = () => {
    switch(currentSection) {
      case 'inicio':
        return (
          <div className="dashboard-container">
            <div className="bienvenida-header">
              <div className="bienvenida-titulo">
                <h1>¡Bienvenido, Estudiante!</h1>
                <span className="fecha-actual">{new Date().toLocaleDateString()}</span>
              </div>
            </div>

            <div className="resumen-grid">
              <div className="resumen-card">
                <div className="resumen-icono">
                  <i className="fas fa-tasks"></i>
                </div>
                <div className="resumen-valor">5</div>
                <div className="resumen-label">Tareas Pendientes</div>
              </div>
              <div className="resumen-card">
                <div className="resumen-icono">
                  <i className="fas fa-book"></i>
                </div>
                <div className="resumen-valor">8</div>
                <div className="resumen-label">Cursos Activos</div>
              </div>
              <div className="resumen-card">
                <div className="resumen-icono">
                  <i className="fas fa-chart-line"></i>
                </div>
                <div className="resumen-valor">75%</div>
                <div className="resumen-label">Progreso General</div>
              </div>
            </div>
          </div>
        );

      case 'contenido':
        switch(subSection) {
          case 'materiales':
            return (
              <div className="dashboard-container">
                <h2>Materiales del Curso</h2>
                <div className="materiales-grid">
                  <div className="material-card">
                    <div className="material-header">
                      <i className="fas fa-file-pdf"></i>
                      <h3>Documentos</h3>
                    </div>
                    <div className="material-content">
                      <ul className="material-lista">
                        <li>
                          <i className="fas fa-file-pdf"></i>
                          <span>Guía de estudio</span>
                          <button className="btn-download">
                            <i className="fas fa-download"></i>
                          </button>
                        </li>
                        {/* Más materiales */}
                      </ul>
                    </div>
                  </div>
                  <div className="material-card">
                    <div className="material-header">
                      <i className="fas fa-video"></i>
                      <h3>Videos</h3>
                    </div>
                    <div className="material-content">
                      <ul className="material-lista">
                        <li>
                          <i className="fas fa-play-circle"></i>
                          <span>Introducción al curso</span>
                          <button className="btn-play">
                            <i className="fas fa-play"></i>
                          </button>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            );

          case 'documentos':
            // Similar estructura para documentos
            break;
        }
        break;

      case 'tareas':
        switch(subSection) {
          case 'pendientes':
            return (
              <div className="dashboard-container">
                <h2>Tareas Pendientes</h2>
                <div className="tareas-grid">
                  <div className="tarea-card">
                    <div className="tarea-header">
                      <h3>Actividad 1</h3>
                      <span className="fecha-entrega">Entrega: 20/04/2024</span>
                    </div>
                    <div className="tarea-content">
                      <p>Descripción de la tarea...</p>
                      <div className="tarea-acciones">
                        <button className="btn-accion">
                          <i className="fas fa-upload"></i>
                          Entregar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );

          case 'calificaciones':
            return (
              <div className="dashboard-container">
                <h2>Mis Calificaciones</h2>
                <div className="calificaciones-tabla">
                  <table className="tabla-datos">
                    <thead>
                      <tr>
                        <th>Actividad</th>
                        <th>Calificación</th>
                        <th>Retroalimentación</th>
                        <th>Fecha</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Filas de calificaciones */}
                    </tbody>
                  </table>
                </div>
              </div>
            );
        }
        break;

      case 'comunicacion':
        switch(subSection) {
          case 'mensajes':
            return (
              <div className="dashboard-container">
                <h2>Mensajes</h2>
                <div className="mensajes-container">
                  <div className="mensajes-lista">
                    {/* Lista de mensajes */}
                  </div>
                  <div className="mensaje-nuevo">
                    <button className="btn-accion">
                      <i className="fas fa-plus"></i>
                      Nuevo Mensaje
                    </button>
                  </div>
                </div>
              </div>
            );

          case 'foros':
            return (
              <div className="dashboard-container">
                <h2>Foros de Discusión</h2>
                <div className="foros-grid">
                  {/* Lista de foros */}
                </div>
              </div>
            );
        }
        break;

      case 'progreso':
        switch(subSection) {
          case 'estadisticas':
            return (
              <div className="dashboard-container">
                <h2>Mis Estadísticas</h2>
                <div className="estadisticas-container">
                  <div className="grafica-progreso">
                    {/* Gráfica de progreso */}
                  </div>
                  <div className="detalles-progreso">
                    {/* Detalles de avance */}
                  </div>
                </div>
              </div>
            );

          case 'certificados':
            return (
              <div className="dashboard-container">
                <h2>Mis Certificados</h2>
                <div className="certificados-grid">
                  {/* Lista de certificados */}
                </div>
              </div>
            );
        }
        break;

      case 'configuracion':
        return (
          <div className="dashboard-container">
            <h2>Configuración de Perfil</h2>
            <div className="config-container">
              <form className="config-form">
                <div className="form-group">
                  <label>Foto de Perfil</label>
                  <input type="file" className="form-control" />
                </div>
                <div className="form-group">
                  <label>Nombre</label>
                  <input type="text" className="form-control" />
                </div>
                <div className="form-group">
                  <label>Preferencias de Notificación</label>
                  <div className="checkbox-group">
                    <label>
                      <input type="checkbox" />
                      Notificaciones por email
                    </label>
                    <label>
                      <input type="checkbox" />
                      Notificaciones en plataforma
                    </label>
                  </div>
                </div>
                <button type="submit" className="btn-accion">
                  <i className="fas fa-save"></i>
                  Guardar Cambios
                </button>
              </form>
            </div>
          </div>
        );

      case 'cursos':
        return (
          <div className="dashboard-container">
            <div className="cursos-header">
              <h2>Cursos inscritos</h2>
              <button 
                className="btn-estadisticas"
                onClick={() => setShowStats(!showStats)}
              >
                <i className="fas fa-chart-bar"></i>
                {showStats ? 'Ocultar estadísticas' : 'Mostrar estadísticas'}
              </button>
            </div>

            {showStats && (
              <div className="cursos-stats">
                <div className="stat-item">
                  <i className="fas fa-star"></i>
                  <span>Reseñas</span>
                  <div className="stat-value">0</div>
                </div>
                <div className="stat-item">
                  <i className="fas fa-certificate"></i>
                  <span>Certificados</span>
                  <div className="stat-value">0</div>
                </div>
              </div>
            )}

            <div className="cursos-progress">
              <div 
                className={`progress-item ${currentFilter === 'todos' ? 'active' : ''}`}
                onClick={() => setCurrentFilter('todos')}
              >
                <i className="fas fa-list"></i>
                <span>Todos</span>
                <div className="progress-value">{cursos.length}</div>
              </div>
              <div 
                className={`progress-item ${currentFilter === 'completado' ? 'active' : ''}`}
                onClick={() => setCurrentFilter('completado')}
              >
                <i className="fas fa-check-circle"></i>
                <span>Completado</span>
                <div className="progress-value">
                  {cursos.filter(c => c.estado === 'completado').length}
                </div>
              </div>
              <div 
                className={`progress-item ${currentFilter === 'en_progreso' ? 'active' : ''}`}
                onClick={() => setCurrentFilter('en_progreso')}
              >
                <i className="fas fa-clock"></i>
                <span>En progreso</span>
                <div className="progress-value">
                  {cursos.filter(c => c.estado === 'en_progreso').length}
                </div>
              </div>
              <div 
                className={`progress-item ${currentFilter === 'fallido' ? 'active' : ''}`}
                onClick={() => setCurrentFilter('fallido')}
              >
                <i className="fas fa-times-circle"></i>
                <span>Fallido</span>
                <div className="progress-value">
                  {cursos.filter(c => c.estado === 'fallido').length}
                </div>
              </div>
            </div>

            <div className="cursos-grid">
              {filtrarCursos().map(curso => (
                <div className="curso-card" key={curso.id}>
                  <div className="curso-info">
                    <span className="curso-tipo">{curso.tipo}</span>
                    <h3>{curso.titulo}</h3>
                    <div className="curso-meta">
                      <span className="curso-duracion">
                        <i className="fas fa-clock"></i>
                        {curso.duracion}
                      </span>
                      <span className="curso-progreso">{curso.progreso}% Completo</span>
                    </div>
                  </div>
                  <button className="btn-iniciar">INICIAR EL CURSO</button>
                  <span className="curso-fecha">Iniciado {curso.fecha}</span>
                </div>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="dashboard-layout">
      <div className="sidebar">
        <div className="logo">
          <h2>Estudiante</h2>
        </div>
        <nav>
          {/* Inicio */}
          <a 
            onClick={() => handleMenuClick('inicio')} 
            className={`nav-item ${currentSection === 'inicio' ? 'active' : ''}`}
          >
            <i className="fas fa-home"></i>
            <span>Inicio</span>
          </a>

          {/* Cursos */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('cursos')} 
              className={`nav-item ${currentSection === 'cursos' ? 'active' : ''}`}
            >
              <i className="fas fa-graduation-cap"></i>
              <span>Cursos</span>
            </a>
          </div>

          {/* Contenido */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('contenido')} 
              className={`nav-item ${currentSection === 'contenido' ? 'active' : ''}`}
            >
              <i className="fas fa-book"></i>
              <span>Contenido</span>
              <i className={`fas fa-chevron-${showSubMenu === 'contenido' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'contenido' && (
              <div className="submenu">
                <a onClick={() => setSubSection('materiales')} className="submenu-item">
                  <i className="fas fa-file-alt"></i>
                  <span>Materiales</span>
                </a>
                <a onClick={() => setSubSection('documentos')} className="submenu-item">
                  <i className="fas fa-folder"></i>
                  <span>Documentos</span>
                </a>
              </div>
            )}
          </div>

          {/* Tareas y Actividades */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('tareas')} 
              className={`nav-item ${currentSection === 'tareas' ? 'active' : ''}`}
            >
              <i className="fas fa-tasks"></i>
              <span>Tareas y Actividades</span>
              <i className={`fas fa-chevron-${showSubMenu === 'tareas' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'tareas' && (
              <div className="submenu">
                <a onClick={() => setSubSection('pendientes')} className="submenu-item">
                  <i className="fas fa-clock"></i>
                  <span>Pendientes</span>
                </a>
                <a onClick={() => setSubSection('entregas')} className="submenu-item">
                  <i className="fas fa-upload"></i>
                  <span>Entregas</span>
                </a>
                <a onClick={() => setSubSection('calificaciones')} className="submenu-item">
                  <i className="fas fa-star"></i>
                  <span>Calificaciones</span>
                </a>
              </div>
            )}
          </div>

          {/* Comunicación */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('comunicacion')} 
              className={`nav-item ${currentSection === 'comunicacion' ? 'active' : ''}`}
            >
              <i className="fas fa-comments"></i>
              <span>Comunicación</span>
              <i className={`fas fa-chevron-${showSubMenu === 'comunicacion' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'comunicacion' && (
              <div className="submenu">
                <a onClick={() => setSubSection('mensajes')} className="submenu-item">
                  <i className="fas fa-envelope"></i>
                  <span>Mensajes</span>
                </a>
                <a onClick={() => setSubSection('foros')} className="submenu-item">
                  <i className="fas fa-users"></i>
                  <span>Foros</span>
                </a>
                <a onClick={() => setSubSection('notificaciones')} className="submenu-item">
                  <i className="fas fa-bell"></i>
                  <span>Notificaciones</span>
                </a>
              </div>
            )}
          </div>

          {/* Progreso */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('progreso')} 
              className={`nav-item ${currentSection === 'progreso' ? 'active' : ''}`}
            >
              <i className="fas fa-chart-line"></i>
              <span>Mi Progreso</span>
              <i className={`fas fa-chevron-${showSubMenu === 'progreso' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'progreso' && (
              <div className="submenu">
                <a onClick={() => setSubSection('estadisticas')} className="submenu-item">
                  <i className="fas fa-chart-bar"></i>
                  <span>Estadísticas</span>
                </a>
                <a onClick={() => setSubSection('certificados')} className="submenu-item">
                  <i className="fas fa-certificate"></i>
                  <span>Certificados</span>
                </a>
              </div>
            )}
          </div>

          {/* Configuración */}
          <a 
            onClick={() => handleMenuClick('configuracion')} 
            className={`nav-item ${currentSection === 'configuracion' ? 'active' : ''}`}
          >
            <i className="fas fa-cog"></i>
            <span>Configuración</span>
          </a>

          <button onClick={handleLogout} className="logout-btn">
            <i className="fas fa-sign-out-alt"></i>
            <span>Cerrar Sesión</span>
          </button>
        </nav>
      </div>
      <div className="main-content">
        {renderDashboardContent()}
      </div>
    </div>
  );
};

export default EstudianteDashboard;
