// StudentDashboard.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import '../../styles/components/AdminDashboard.css';
import '../../styles/registrar.css';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState('inicio');
  const [subSection, setSubSection] = useState('');
  const [showSubMenu, setShowSubMenu] = useState('');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('estudiante');
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [usuarios, setUsuarios] = useState([]);
  const [editandoUsuario, setEditandoUsuario] = useState(null);
  const [cursos, setCursos] = useState([]);
  const [profesores, setProfesores] = useState([]);
  const [cursoSeleccionado, setCursoSeleccionado] = useState('');
  const [profesorSeleccionado, setProfesorSeleccionado] = useState('');

  useEffect(() => {
    if (currentSection === 'usuarios' && subSection === 'roles') {
      cargarUsuarios();
    }
  }, [currentSection, subSection]);

  useEffect(() => {
    if (currentSection === 'usuarios' && subSection === 'asignaciones') {
      cargarCursos();
      cargarProfesores();
    }
  }, [currentSection, subSection]);

  const handleMenuClick = (section) => {
    if (showSubMenu === section) {
      setShowSubMenu('');
    } else {
      setShowSubMenu(section);
    }
    setCurrentSection(section);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      setMessage('Las contraseñas no coinciden');
      return;
    }
    
    try {
      localStorage.setItem(email, JSON.stringify({ 
        nombre,
        apellido,
        password, 
        role 
      }));
      setMessage('Usuario registrado exitosamente');
      // Limpia el formulario
      setNombre('');
      setApellido('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setRole('estudiante');
      // Redirige al listado de usuarios después de 2 segundos
      setTimeout(() => {
        setSubSection('listado');
      }, 2000);
    } catch (error) {
      setMessage('Error al registrar usuario');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
    navigate('/');
  };

  const asignarCursoAProfesor = (profesorEmail) => {
    const nuevoCurso = {
      id: Date.now(),
      nombre: 'Nombre del curso',
      categoria: 'categoria_seleccionada',
      profesorEmail: profesorEmail, // Email del profesor al que se asigna
   
      estado: 'activo',
      fecha: new Date().toLocaleDateString()
    };

    // Obtener cursos existentes o array vacío si no hay
    const cursosActuales = JSON.parse(localStorage.getItem('cursos')) || [];
    
    // Añadir el nuevo curso
    cursosActuales.push(nuevoCurso);
    
    // Guardar en localStorage
    localStorage.setItem('cursos', JSON.stringify(cursosActuales));
  };

  const cargarUsuarios = () => {
    const keys = Object.keys(localStorage);
    const usuariosEncontrados = keys
      .filter(key => key !== 'currentUser' && key !== 'userRole' && key !== 'cursos')
      .map(email => {
        const userData = JSON.parse(localStorage.getItem(email));
        return { email, ...userData };
      });
    setUsuarios(usuariosEncontrados);
  };

  const actualizarRol = (email, nuevoRol) => {
    try {
      const userData = JSON.parse(localStorage.getItem(email));
      userData.role = nuevoRol;
      localStorage.setItem(email, JSON.stringify(userData));
      cargarUsuarios(); // Recargar la lista
      setMessage('Rol actualizado exitosamente');
      setTimeout(() => setMessage(''), 2000);
    } catch (error) {
      setMessage('Error al actualizar el rol');
    }
  };

  const cargarCursos = () => {
    const cursosGuardados = JSON.parse(localStorage.getItem('cursos')) || [];
    setCursos(cursosGuardados);
  };

  const cargarProfesores = () => {
    const keys = Object.keys(localStorage);
    const keysAExcluir = ['userRole', 'currentUser', 'cursos']; // Lista de claves a excluir

    const profesoresEncontrados = keys
      .filter(key => !keysAExcluir.includes(key)) // Primero filtramos las claves que queremos excluir
      .filter(key => {
        try {
          const userData = JSON.parse(localStorage.getItem(key));
          return userData && userData.role === 'profesor';
        } catch (error) {
          // Solo logueamos errores para claves que no están en nuestra lista de exclusión
          console.log(`Omitiendo clave ${key} - no es un usuario válido`);
          return false;
        }
      })
      .map(email => {
        const userData = JSON.parse(localStorage.getItem(email));
        return {
          email,
          nombre: userData.nombre || 'Sin nombre',
          apellido: userData.apellido || 'Sin apellido'
        };
      });

    setProfesores(profesoresEncontrados);
  };

  const asignarCurso = (e) => {
    e.preventDefault();
    if (!cursoSeleccionado || !profesorSeleccionado) {
      setMessage('Por favor, selecciona un curso y un profesor');
      return;
    }

    const cursosActualizados = cursos.map(curso => {
      if (curso.id === parseInt(cursoSeleccionado)) {
        return { ...curso, profesorEmail: profesorSeleccionado };
      }
      return curso;
    });

    localStorage.setItem('cursos', JSON.stringify(cursosActualizados));
    setCursos(cursosActualizados);
    setMessage('Curso asignado exitosamente');
    setCursoSeleccionado('');
    setProfesorSeleccionado('');
  };

  const renderDashboardContent = () => {
    switch(currentSection) {
      case 'inicio':
        return (
          <div className="dashboard-container">
            <div className="bienvenida-header">
              <div className="bienvenida-titulo">
                <h1>Panel de Administración</h1>
                <span className="fecha-actual">{new Date().toLocaleDateString()}</span>
              </div>
            </div>

            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon">
                  <i className="fas fa-users"></i>
                </div>
                <div className="stat-info">
                  <div className="stat-value">1,234</div>
                  <div className="stat-label">Usuarios Activos</div>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">
                  <i className="fas fa-graduation-cap"></i>
                </div>
                <div className="stat-info">
                  <div className="stat-value">56</div>
                  <div className="stat-label">Cursos Activos</div>
                </div>
              </div>
              <div className="stat-card">
                <div className="stat-icon">
                  <i className="fas fa-building"></i>
                </div>
                <div className="stat-info">
                  <div className="stat-value">15</div>
                  <div className="stat-label">Empresas</div>
                </div>
              </div>
            </div>

            <div className="quick-actions">
              <h2>Acciones Rápidas</h2>
              <div className="actions-grid">
                <button className="action-btn">
                  <i className="fas fa-plus-circle"></i>
                  Crear Usuario
                </button>
                <button className="action-btn">
                  <i className="fas fa-cog"></i>
                  Configurar Sistema
                </button>
                <button className="action-btn">
                  <i className="fas fa-chart-bar"></i>
                  Ver Reportes
                </button>
              </div>
            </div>
          </div>
        );

      case 'contenido':
        switch(subSection) {
          case 'repositorio':
            return (
              <div className="dashboard-container">
                <h2>Repositorio Global de Contenido</h2>
                <div className="content-actions">
                  <button className="btn-primary">
                    <i className="fas fa-plus"></i>
                    Nuevo Contenido
                  </button>
                  <button className="btn-secondary">
                    <i className="fas fa-filter"></i>
                    Filtrar
                  </button>
                </div>
                <div className="content-grid">
                  {/* Lista de contenido */}
                </div>
              </div>
            );
          case 'politicas':
            return (
              <div className="dashboard-container">
                <h2>Políticas de Acceso</h2>
                <div className="policies-container">
                  <div className="policy-form">
                    <h3>Configurar Políticas</h3>
                    {/* Formulario de políticas */}
                  </div>
                </div>
              </div>
            );
        }
        break;

      case 'comunicacion':
        switch(subSection) {
          case 'canales':
            return (
              <div className="dashboard-container">
                <h2>Gestión de Canales de Comunicación</h2>
                <div className="channels-grid">
                  <div className="channel-card">
                    <h3>Foros Globales</h3>
                    <div className="channel-actions">
                      <button className="btn-primary">Configurar</button>
                      <button className="btn-secondary">Estadísticas</button>
                    </div>
                  </div>
                  {/* Más canales */}
                </div>
              </div>
            );
          case 'estadisticas':
            return (
              <div className="dashboard-container">
                <h2>Estadísticas de Comunicación</h2>
                <div className="stats-container">
                  {/* Gráficos y estadísticas */}
                </div>
              </div>
            );
        }
        break;

      case 'evaluacion':
        switch(subSection) {
          case 'criterios':
            return (
              <div className="dashboard-container">
                <h2>Criterios de Evaluación</h2>
                <div className="criteria-container">
                  <div className="criteria-form">
                    <h3>Definir Criterios</h3>
                    {/* Formulario de criterios */}
                  </div>
                </div>
              </div>
            );
          case 'plantillas':
            return (
              <div className="dashboard-container">
                <h2>Plantillas de Actividades</h2>
                <div className="templates-grid">
                  {/* Lista de plantillas */}
                </div>
              </div>
            );
        }
        break;

      case 'usuarios':
        switch(subSection) {
          case 'registro':
            return (
              <div className="dashboard-container">
                <div className="register-container">
                  <form onSubmit={handleSubmit} className="register-form">
                    <h2>Registrar Usuario</h2>
                    
                    {message && <div className="message">{message}</div>}
                    
                    <div className="form-group">
                      <input
                        type="text"
                        placeholder="Nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        required
                      />
                    </div>

                    <div className="form-group">
                      <input
                        type="text"
                        placeholder="Apellido"
                        value={apellido}
                        onChange={(e) => setApellido(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="form-group">
                      <input
                        type="email"
                        placeholder="Correo electrónico"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="form-group">
                      <input
                        type="password"
                        placeholder="Contraseña"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                    </div>

                    <div className="form-group">
                      <input
                        type="password"
                        placeholder="Confirmar contraseña"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                      />
                    </div>

                    <div className="form-group">
                      <select 
                        value={role} 
                        onChange={(e) => setRole(e.target.value)}
                        className="role-select"
                      >
                        <option value="estudiante">Estudiante</option>
                        <option value="profesor">Profesor</option>
                        <option value="cliente">Cliente</option>
                      </select>
                    </div>

                    <button type="submit">Registrar</button>
                  </form>
                </div>
              </div>
            );
          case 'roles':
            return (
              <div className="dashboard-container">
                <h2>Gestión de Usuarios y Roles</h2>
                {message && <div className="message">{message}</div>}
                
                <div className="usuarios-table-container">
                  <table className="usuarios-table">
                    <thead>
                      <tr>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Rol Actual</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {usuarios.map(usuario => (
                        <tr key={usuario.email}>
                          <td>{usuario.nombre}</td>
                          <td>{usuario.apellido}</td>
                          <td>{usuario.email}</td>
                          <td>{usuario.role}</td>
                          <td>
                            {editandoUsuario === usuario.email ? (
                              <div className="role-edit">
                                <select 
                                  defaultValue={usuario.role}
                                  onChange={(e) => actualizarRol(usuario.email, e.target.value)}
                                >
                                  <option value="estudiante">Estudiante</option>
                                  <option value="profesor">Profesor</option>
                                  <option value="cliente">Cliente</option>
                                  <option value="admin">Admin</option>
                                </select>
                                <button 
                                  onClick={() => setEditandoUsuario(null)}
                                  className="btn-cancelar"
                                >
                                  <i className="fas fa-times"></i>
                                </button>
                              </div>
                            ) : (
                              <button 
                                onClick={() => setEditandoUsuario(usuario.email)}
                                className="btn-editar"
                              >
                                <i className="fas fa-edit"></i> Cambiar Rol
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          case 'asignaciones':
            return (
              <div className="dashboard-container">
                <h2>Asignación de Cursos a Profesores</h2>
                {message && <div className="message">{message}</div>}
                <form onSubmit={asignarCurso} className="asignacion-form">
                  <div className="form-group">
                    <label htmlFor="curso">Seleccionar Curso:</label>
                    <select
                      id="curso"
                      value={cursoSeleccionado}
                      onChange={(e) => setCursoSeleccionado(e.target.value)}
                      required
                    >
                      <option value="">Seleccione un curso</option>
                      {cursos.map(curso => (
                        <option key={curso.id} value={curso.id}>{curso.nombre}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label htmlFor="profesor">Seleccionar Profesor:</label>
                    <select
                      id="profesor"
                      value={profesorSeleccionado}
                      onChange={(e) => setProfesorSeleccionado(e.target.value)}
                      required
                    >
                      <option value="">Seleccione un profesor</option>
                      {profesores.map(profesor => (
                        <option key={profesor.email} value={profesor.email}>{profesor.nombre} {profesor.apellido}</option>
                      ))}
                    </select>
                  </div>
                  <button type="submit" className="btn-asignar">Asignar Curso</button>
                </form>
                <div className="asignaciones-actuales">
                  <h3>Asignaciones Actuales</h3>
                  <ul>
                    {cursos.filter(curso => curso.profesorEmail).map(curso => (
                      <li key={curso.id}>
                        {curso.nombre} - Asignado a: {profesores.find(p => p.email === curso.profesorEmail)?.nombre || curso.profesorEmail}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          case 'listado':
            return (
              <div className="dashboard-container">
                <h2>Listado de Usuarios</h2>
                <div className="usuarios-filtros">
                  <div className="filtro-grupo">
                    <select className="form-control">
                      <option value="">Todos los roles</option>
                      <option value="estudiante">Estudiantes</option>
                      <option value="profesor">Profesores</option>
                      <option value="cliente">Clientes</option>
                    </select>
                    <input 
                      type="search" 
                      className="form-control" 
                      placeholder="Buscar usuario..." 
                    />
                  </div>
                </div>
                <div className="table-container">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Rol</th>
                        <th>Empresa</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Aquí irían los usuarios listados */}
                    </tbody>
                  </table>
                </div>
              </div>
            );
        }
        break;

      case 'reportes':
        switch(subSection) {
          case 'analiticas':
            return (
              <div className="dashboard-container">
                <h2>Analíticas Globales</h2>
                <div className="analytics-dashboard">
                  {/* Gráficos y métricas */}
                </div>
              </div>
            );
          case 'personalizados':
            return (
              <div className="dashboard-container">
                <h2>Reportes Personalizados</h2>
                <div className="custom-reports">
                  <div className="report-builder">
                    {/* Constructor de reportes */}
                  </div>
                </div>
              </div>
            );
        }
        break;

      case 'configuracion':
        return (
          <div className="dashboard-container">
            <h2>Configuración del Sistema</h2>
            <div className="config-grid">
              <div className="config-section">
                <h3>Configuración General</h3>
                <form className="config-form">
                  {/* Formulario de configuración */}
                </form>
              </div>
              <div className="config-section">
                <h3>Integraciones</h3>
                <div className="integrations-list">
                  {/* Lista de integraciones */}
                </div>
              </div>
            </div>
          </div>
        );

      case 'asignar_curso':
        return (
          <div className="dashboard-container">
            <h2>Asignar Curso a Profesor</h2>
            <form onSubmit={(e) => {
              e.preventDefault();
              const profesorEmail = e.target.profesor.value;
              asignarCursoAProfesor(profesorEmail);
            }}>
              <div className="form-group">
                <label>Profesor</label>
                <input 
                  type="email" 
                  name="profesor" 
                  required 
                  placeholder="Email del profesor"
                />
              </div>
              <button type="submit" className="btn-accion">
                Asignar Curso
              </button>
            </form>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="dashboard-layout">
      <div className="sidebar">
        <div className="logo">
          <h2>Administrador</h2>
        </div>
        <nav className="sidebar-nav">
          {/* Inicio */}
          <a 
            onClick={() => handleMenuClick('inicio')} 
            className={`nav-item ${currentSection === 'inicio' ? 'active' : ''}`}
          >
            <i className="fas fa-home"></i>
            <span>Inicio</span>
          </a>

          {/* Gestión de Contenido */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('contenido')} 
              className={`nav-item ${currentSection === 'contenido' ? 'active' : ''}`}
            >
              <i className="fas fa-folder"></i>
              <span>Gestión de Contenido</span>
              <i className={`fas fa-chevron-${showSubMenu === 'contenido' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'contenido' && (
              <div className="submenu">
                <a onClick={() => setSubSection('repositorio')} className="submenu-item">
                  <i className="fas fa-database"></i>
                  <span>Repositorio Global</span>
                </a>
                <a onClick={() => setSubSection('politicas')} className="submenu-item">
                  <i className="fas fa-lock"></i>
                  <span>Políticas de Acceso</span>
                </a>
              </div>
            )}
          </div>

          {/* Comunicación */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('comunicacion')} 
              className={`nav-item ${currentSection === 'comunicacion' ? 'active' : ''}`}
            >
              <i className="fas fa-comments"></i>
              <span>Comunicación</span>
              <i className={`fas fa-chevron-${showSubMenu === 'comunicacion' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'comunicacion' && (
              <div className="submenu">
                <a onClick={() => setSubSection('canales')} className="submenu-item">
                  <i className="fas fa-bullhorn"></i>
                  <span>Canales Globales</span>
                </a>
                <a onClick={() => setSubSection('estadisticas')} className="submenu-item">
                  <i className="fas fa-chart-bar"></i>
                  <span>Estadísticas de Uso</span>
                </a>
              </div>
            )}
          </div>

          {/* Evaluación */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('evaluacion')} 
              className={`nav-item ${currentSection === 'evaluacion' ? 'active' : ''}`}
            >
              <i className="fas fa-tasks"></i>
              <span>Evaluación</span>
              <i className={`fas fa-chevron-${showSubMenu === 'evaluacion' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'evaluacion' && (
              <div className="submenu">
                <a onClick={() => setSubSection('criterios')} className="submenu-item">
                  <i className="fas fa-list-check"></i>
                  <span>Criterios de Evaluación</span>
                </a>
                <a onClick={() => setSubSection('plantillas')} className="submenu-item">
                  <i className="fas fa-file-alt"></i>
                  <span>Plantillas de Actividades</span>
                </a>
              </div>
            )}
          </div>

          {/* Gestión de Usuarios */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('usuarios')} 
              className={`nav-item ${currentSection === 'usuarios' ? 'active' : ''}`}
            >
              <i className="fas fa-users-cog"></i>
              <span>Gestión de Usuarios</span>
              <i className={`fas fa-chevron-${showSubMenu === 'usuarios' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'usuarios' && (
              <div className="submenu">
                <a onClick={() => setSubSection('roles')} className="submenu-item">
                  <i className="fas fa-user-tag"></i>
                  <span>Roles y Permisos</span>
                </a>
                <a onClick={() => setSubSection('registro')} className="submenu-item">
                  <i className="fas fa-user-plus"></i>
                  <span>Registrar Usuario</span>
                </a>
                <a onClick={() => setSubSection('asignaciones')} className="submenu-item">
                  <i className="fas fa-users-cog"></i>
                  <span>Asignaciones</span>
                </a>
              </div>
            )}
          </div>

          {/* Reportes */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('reportes')} 
              className={`nav-item ${currentSection === 'reportes' ? 'active' : ''}`}
            >
              <i className="fas fa-chart-line"></i>
              <span>Reportes</span>
              <i className={`fas fa-chevron-${showSubMenu === 'reportes' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'reportes' && (
              <div className="submenu">
                <a onClick={() => setSubSection('analiticas')} className="submenu-item">
                  <i className="fas fa-analytics"></i>
                  <span>Analíticas Globales</span>
                </a>
                <a onClick={() => setSubSection('personalizados')} className="submenu-item">
                  <i className="fas fa-file-contract"></i>
                  <span>Reportes Personalizados</span>
                </a>
              </div>
            )}
          </div>

          {/* Configuración */}
          <a 
            onClick={() => handleMenuClick('configuracion')} 
            className={`nav-item ${currentSection === 'configuracion' ? 'active' : ''}`}
          >
            <i className="fas fa-cog"></i>
            <span>Configuración</span>
          </a>

          {/* Botón de Cerrar Sesión */}
          <button onClick={handleLogout} className="logout-btn">
            <i className="fas fa-sign-out-alt"></i>
            <span>Cerrar Sesión</span>
          </button>
        </nav>
      </div>
      <div className="main-content">
        {renderDashboardContent()}
      </div>
    </div>
  );
};

export default AdminDashboard;