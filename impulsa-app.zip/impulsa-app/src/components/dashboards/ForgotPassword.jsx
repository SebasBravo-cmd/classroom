import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../styles/ForgotPassword.css"; // Asegúrate de crear también el archivo CSS para los estilos

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const navigate = useNavigate();

  const handleResetPassword = (e) => {
    e.preventDefault();
    // Lógica para manejar el reseteo de la contraseña
    alert(`Se ha enviado un correo de recuperación a: ${email}`);
    navigate("/"); // Redirige al usuario de vuelta a la página de inicio, por ejemplo
  };

  return (
    <div className="forgot-password-container">
      <h1>Recupera tu contraseña</h1>
      <form onSubmit={handleResetPassword}>
        <input
          type="email"
          placeholder="Dirección de correo electrónico"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button type="submit">Enviar enlace de recuperación</button>
      </form>
    </div>
  );
};

export default ForgotPassword;
