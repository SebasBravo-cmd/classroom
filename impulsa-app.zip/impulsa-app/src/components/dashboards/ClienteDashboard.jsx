// StudentDashboard.jsx
import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import '../../styles/components/ClienteDashboard.css';

const ClienteDashboard = () => {
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState('inicio');
  const [subSection, setSubSection] = useState('');
  const [showSubMenu, setShowSubMenu] = useState('');

  const handleMenuClick = (section) => {
    if (showSubMenu === section) {
      setShowSubMenu('');
    } else {
      setShowSubMenu(section);
    }
    setCurrentSection(section);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
    navigate('/');
  };

  const renderDashboardContent = () => {
    switch(currentSection) {
      case 'inicio':
        return (
          <div className="dashboard-container">
            <div className="bienvenida-header">
              <div className="bienvenida-titulo">
                <h1>¡Bienvenido, Cliente!</h1>
                <span className="fecha-actual">
                  {new Date().toLocaleDateString()}
                </span>
              </div>
            </div>

            <div className="estadisticas-grid">
              <div className="estadistica-card">
                <div className="estadistica-icono">
                  <i className="fas fa-users"></i>
                </div>
                <div className="estadistica-valor">25</div>
                <div className="estadistica-label">Profesores Activos</div>
              </div>
              <div className="estadistica-card">
                <div className="estadistica-icono">
                  <i className="fas fa-graduation-cap"></i>
                </div>
                <div className="estadistica-valor">150</div>
                <div className="estadistica-label">Cursos Asignados</div>
              </div>
              <div className="estadistica-card">
                <div className="estadistica-icono">
                  <i className="fas fa-certificate"></i>
                </div>
                <div className="estadistica-valor">45</div>
                <div className="estadistica-label">Certificaciones Emitidas</div>
              </div>
            </div>
          </div>
        );

      case 'recursos':
        switch(subSection) {
          case 'materiales':
            return (
              <div className="dashboard-container">
                <h2>Materiales Asignados</h2>
                <div className="materiales-grid">
                  <div className="material-card">
                    <div className="material-header">
                      <i className="fas fa-file-pdf"></i>
                      <h3>Documentos Corporativos</h3>
                    </div>
                    <div className="material-content">
                      <p>Materiales generales asignados a su empresa</p>
                      <button className="btn-accion">
                        <i className="fas fa-download"></i>
                        Consultar Materiales
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          case 'recursos-especificos':
            return (
              <div className="dashboard-container">
                <h2>Recursos Específicos</h2>
                <div className="recursos-grid">
                  <div className="recurso-card">
                    <h3>Recursos por Profesor</h3>
                    <div className="recurso-acciones">
                      <button className="btn-accion">
                        <i className="fas fa-search"></i>
                        Visualizar Recursos
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          default:
            return (
              <div className="dashboard-container">
                <h2>Recursos y Materiales</h2>
                <p>Seleccione una opción del menú lateral</p>
              </div>
            );
        }

      case 'seguimiento':
        switch(subSection) {
          case 'avance':
            return (
              <div className="dashboard-container">
                <h2>Avance de Actividades</h2>
                <div className="avance-content">
                  <div className="avance-filtros">
                    <select className="form-control">
                      <option>Todos los profesores</option>
                      {/* Opciones de profesores */}
                    </select>
                  </div>
                  <div className="avance-tabla">
                    {/* Tabla de avance */}
                  </div>
                </div>
              </div>
            );
          case 'reportes':
            return (
              <div className="dashboard-container">
                <h2>Reportes Globales</h2>
                <div className="reportes-grid">
                  <div className="reporte-card">
                    <h3>Reportes por Curso</h3>
                    <button className="btn-accion">
                      <i className="fas fa-file-download"></i>
                      Descargar Reporte
                    </button>
                  </div>
                  <div className="reporte-card">
                    <h3>Reportes por Grupo</h3>
                    <button className="btn-accion">
                      <i className="fas fa-file-download"></i>
                      Descargar Reporte
                    </button>
                  </div>
                </div>
              </div>
            );
          case 'desempeno':
            return (
              <div className="dashboard-container">
                <h2>Desempeño de Profesores</h2>
                <div className="desempeno-content">
                  <div className="graficas-container">
                    {/* Gráficas de desempeño */}
                  </div>
                  <div className="desempeno-acciones">
                    <button className="btn-accion">
                      <i className="fas fa-download"></i>
                      Exportar Datos
                    </button>
                  </div>
                </div>
              </div>
            );
          default:
            return (
              <div className="dashboard-container">
                <h2>Seguimiento</h2>
                <p>Seleccione una opción del menú lateral</p>
              </div>
            );
        }

      case 'certificaciones':
        switch(subSection) {
          case 'estadisticas':
            return (
              <div className="dashboard-container">
                <h2>Estadísticas de Certificaciones</h2>
                <div className="certificaciones-stats">
                  <div className="stat-card">
                    <h3>Certificaciones Totales</h3>
                    <div className="stat-valor">120</div>
                  </div>
                  <div className="stat-card">
                    <h3>En Proceso</h3>
                    <div className="stat-valor">45</div>
                  </div>
                </div>
              </div>
            );
          case 'reportes-corp':
            return (
              <div className="dashboard-container">
                <h2>Reportes Corporativos</h2>
                <div className="reportes-corp-content">
                  <button className="btn-accion">
                    <i className="fas fa-file-download"></i>
                    Descargar Reporte Corporativo
                  </button>
                </div>
              </div>
            );
          default:
            return (
              <div className="dashboard-container">
                <h2>Certificaciones</h2>
                <p>Seleccione una opción del menú lateral</p>
              </div>
            );
        }

      case 'configuracion':
        return (
          <div className="dashboard-container">
            <h2>Configuración</h2>
            <div className="config-grid">
              <div className="config-card">
                <h3>Datos Corporativos</h3>
                <form className="config-form">
                  <div className="form-group">
                    <label>Logo Empresarial</label>
                    <input type="file" className="form-control" />
                  </div>
                  <div className="form-group">
                    <label>Nombre de la Empresa</label>
                    <input type="text" className="form-control" />
                  </div>
                  <button type="submit" className="btn-accion">
                    <i className="fas fa-save"></i>
                    Guardar Cambios
                  </button>
                </form>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="dashboard-layout">
      <div className="sidebar">
        <div className="logo">
          <h2>Cliente</h2>
        </div>
        <nav>
          {/* Inicio */}
          <a 
            onClick={() => handleMenuClick('inicio')} 
            className={`nav-item ${currentSection === 'inicio' ? 'active' : ''}`}
          >
            <i className="fas fa-home"></i>
            <span>Inicio</span>
          </a>

          {/* Recursos y Materiales */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('recursos')} 
              className={`nav-item ${currentSection === 'recursos' ? 'active' : ''}`}
            >
              <i className="fas fa-book"></i>
              <span>Recursos y Materiales</span>
              <i className={`fas fa-chevron-${showSubMenu === 'recursos' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'recursos' && (
              <div className="submenu">
                <a onClick={() => setSubSection('materiales')} className="submenu-item">
                  <i className="fas fa-file-alt"></i>
                  <span>Materiales Asignados</span>
                </a>
                <a onClick={() => setSubSection('recursos-especificos')} className="submenu-item">
                  <i className="fas fa-folder"></i>
                  <span>Recursos Específicos</span>
                </a>
              </div>
            )}
          </div>

          {/* Seguimiento */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('seguimiento')} 
              className={`nav-item ${currentSection === 'seguimiento' ? 'active' : ''}`}
            >
              <i className="fas fa-chart-line"></i>
              <span>Seguimiento</span>
              <i className={`fas fa-chevron-${showSubMenu === 'seguimiento' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'seguimiento' && (
              <div className="submenu">
                <a onClick={() => setSubSection('avance')} className="submenu-item">
                  <i className="fas fa-tasks"></i>
                  <span>Avance de Actividades</span>
                </a>
                <a onClick={() => setSubSection('reportes')} className="submenu-item">
                  <i className="fas fa-file-alt"></i>
                  <span>Reportes Globales</span>
                </a>
                <a onClick={() => setSubSection('desempeno')} className="submenu-item">
                  <i className="fas fa-chart-bar"></i>
                  <span>Desempeño de Profesores</span>
                </a>
              </div>
            )}
          </div>

          {/* Certificaciones */}
          <div className="nav-group">
            <a 
              onClick={() => handleMenuClick('certificaciones')} 
              className={`nav-item ${currentSection === 'certificaciones' ? 'active' : ''}`}
            >
              <i className="fas fa-certificate"></i>
              <span>Certificaciones</span>
              <i className={`fas fa-chevron-${showSubMenu === 'certificaciones' ? 'up' : 'down'} submenu-icon`}></i>
            </a>
            {showSubMenu === 'certificaciones' && (
              <div className="submenu">
                <a onClick={() => setSubSection('estadisticas')} className="submenu-item">
                  <i className="fas fa-chart-pie"></i>
                  <span>Estadísticas</span>
                </a>
                <a onClick={() => setSubSection('reportes-corp')} className="submenu-item">
                  <i className="fas fa-file-download"></i>
                  <span>Reportes Corporativos</span>
                </a>
              </div>
            )}
          </div>

          {/* Configuración */}
          <a 
            onClick={() => handleMenuClick('configuracion')} 
            className={`nav-item ${currentSection === 'configuracion' ? 'active' : ''}`}
          >
            <i className="fas fa-cog"></i>
            <span>Configuración</span>
          </a>

          <button onClick={handleLogout} className="logout-btn">
            <i className="fas fa-sign-out-alt"></i>
            <span>Cerrar Sesión</span>
          </button>
        </nav>
      </div>
      <div className="main-content">
        {renderDashboardContent()}
      </div>
    </div>
  );
};

export default ClienteDashboard;