import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Login.css';

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Función para crear el admin por defecto
  const crearAdminPorDefecto = () => {
    const adminEmail = 'admin@admin.com';
    const adminData = {
      email: adminEmail,
      password: 'admin123',
      nombre: 'Administrador',
      apellido: 'Sistema',
      role: 'admin'
    };

    // Solo crear si no existe
    if (!localStorage.getItem(adminEmail)) {
      localStorage.setItem(adminEmail, JSON.stringify(adminData));
      console.log('Administrador por defecto creado');
    }
  };

  // Ejecutar al montar el componente
  useEffect(() => {
    crearAdminPorDefecto();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      console.log('Email intentando acceder:', email);
      const userData = JSON.parse(localStorage.getItem(email));
      console.log('Datos del usuario encontrados:', userData);
      
      if (userData && userData.password === password) {
        console.log('Contraseña correcta, role:', userData.role);
        
        const currentUser = {
          email: email,
          role: userData.role,
          nombre: userData.nombre,
          apellido: userData.apellido
        };
        
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        localStorage.setItem('userRole', userData.role);
        
        console.log('Usuario guardado en localStorage:', currentUser);
        
        switch(userData.role) {
          case 'admin':
            console.log('Redirigiendo a /dashboard/admin');
            navigate('/dashboard/admin');
            break;
          case 'profesor':
            navigate('/dashboard/profesor');
            break;
          case 'estudiante':
            navigate('/dashboard/estudiante');
            break;
          case 'cliente':
            navigate('/dashboard/cliente');
            break;
          default:
            setError('Rol no válido');
        }
      } else {
        console.log('Credenciales inválidas');
        setError('Credenciales inválidas');
      }
    } catch (error) {
      console.error('Error en login:', error);
      setError('Error al iniciar sesión');
    }
  };

  return (
    <div className="login-container">
      <div className="logo">
        <h2>Sistema</h2>
      </div>
      
      <div className="login-form">
        <h2>¡HOLA!</h2>
        <p className="login-subtitle">Inicia tu sesión y potencia tu talento</p>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <input 
              type="email" 
              placeholder="Dirección de correo electrónico" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="form-group">
            <input 
              type="password" 
              placeholder="Contraseña" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <button type="submit">Inicia Sesión</button>
          
          <a href="#" className="forgot-password">*Olvidé mi contraseña</a>
        </form>
      </div>
    </div>
  );
};

export default Login;
