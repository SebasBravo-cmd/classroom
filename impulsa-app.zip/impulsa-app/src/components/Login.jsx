import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Login.css';

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    console.log('Intentando iniciar sesión con:', email, password);
    
    if (email === 'admin@gmail.com' && password === '123456') {
      localStorage.setItem('currentUser', email);
      localStorage.setItem('userRole', 'admin');
      navigate('/dashboard/admin');
      return;
    }

    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    console.log('Usuarios registrados:', registeredUsers);
    
    const user = registeredUsers.find(u => u.email === email && u.password === password);
    console.log('Usuario encontrado:', user);

    if (user && user.rol) {
      localStorage.setItem('currentUser', user.email);
      localStorage.setItem('userRole', user.rol);
      console.log('Redirigiendo a:', `/dashboard/${user.rol}`);
      
      // Redirigir según el rol
      switch(user.rol.toLowerCase()) {
        case 'estudiante':
          navigate('/dashboard/estudiante');
          break;
        case 'profesor':
          navigate('/dashboard/profesor');
          break;
        case 'cliente':
          navigate('/dashboard/cliente');
          break;
        default:
          setError('Rol no reconocido');
      }
    } else {
      setError('Credenciales incorrectas');
    }
  };

  return (
    <div className="login-container">
      <div className="logo">
        <h2>Sistema</h2>
      </div>
      
      <div className="login-form">
        <h2>¡HOLA!</h2>
        <p className="login-subtitle">Inicia tu sesión y potencia tu talento</p>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <input 
              type="email" 
              placeholder="Dirección de correo electrónico" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="form-group">
            <input 
              type="password" 
              placeholder="Contraseña" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          
          <button type="submit">Inicia Sesión</button>
          
          <a href="#" className="forgot-password">*Olvidé mi contraseña</a>
        </form>
      </div>
    </div>
  );
};

export default Login;
