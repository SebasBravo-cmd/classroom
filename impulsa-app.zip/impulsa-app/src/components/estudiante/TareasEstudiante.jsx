import React, { useState, useEffect } from 'react';

const TareasEstudiante = () => {
  const [tareas, setTareas] = useState([]);
  const [filtro, setFiltro] = useState('pendientes'); // pendientes, completadas, todas

  useEffect(() => {
    // Simular carga de tareas
    const tareasDemo = [
      {
        id: 1,
        titulo: 'Proyecto Final',
        descripcion: 'Desarrollar una aplicación web',
        fechaEntrega: '2024-04-01',
        estado: 'pendiente',
        calificacion: null
      },
      {
        id: 2,
        titulo: 'Cuestionario Módulo 1',
        descripcion: 'Responder preguntas sobre conceptos básicos',
        fechaEntrega: '2024-03-15',
        estado: 'completada',
        calificacion: 85
      }
    ];
    setTareas(tareasDemo);
  }, []);

  const filtrarTareas = () => {
    if (filtro === 'todas') return tareas;
    return tareas.filter(tarea => 
      filtro === 'pendientes' ? tarea.estado === 'pendiente' : tarea.estado === 'completada'
    );
  };

  return (
    <div className="section-container">
      <div className="section-header">
        <h2>Mis Tareas</h2>
        <div className="filtros">
          <button 
            className={`filter-btn ${filtro === 'todas' ? 'active' : ''}`}
            onClick={() => setFiltro('todas')}
          >
            Todas
          </button>
          <button 
            className={`filter-btn ${filtro === 'pendientes' ? 'active' : ''}`}
            onClick={() => setFiltro('pendientes')}
          >
            Pendientes
          </button>
          <button 
            className={`filter-btn ${filtro === 'completadas' ? 'active' : ''}`}
            onClick={() => setFiltro('completadas')}
          >
            Completadas
          </button>
        </div>
      </div>

      <div className="tareas-list">
        {filtrarTareas().map(tarea => (
          <div key={tarea.id} className={`tarea-card ${tarea.estado}`}>
            <div className="tarea-header">
              <h3>{tarea.titulo}</h3>
              <span className={`estado-badge ${tarea.estado}`}>
                {tarea.estado}
              </span>
            </div>
            <p>{tarea.descripcion}</p>
            <div className="tarea-footer">
              <span className="fecha">
                Entrega: {new Date(tarea.fechaEntrega).toLocaleDateString()}
              </span>
              {tarea.calificacion && (
                <span className="calificacion">
                  Calificación: {tarea.calificacion}
                </span>
              )}
              {tarea.estado === 'pendiente' && (
                <button className="submit-btn">
                  Entregar Tarea
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TareasEstudiante; 