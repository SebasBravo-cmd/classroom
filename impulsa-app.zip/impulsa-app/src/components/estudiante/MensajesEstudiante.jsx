import React, { useState, useEffect } from 'react';

const MensajesEstudiante = () => {
  const [mensajes, setMensajes] = useState([]);
  const [nuevoMensaje, setNuevoMensaje] = useState('');
  const [destinatario, setDestinatario] = useState('');
  const [profesores, setProfesores] = useState([]);

  useEffect(() => {
    // Simular carga de mensajes y profesores
    const mensajesDemo = [
      {
        id: 1,
        remitente: 'Prof. García',
        mensaje: 'Recuerda entregar el proyecto final antes del viernes',
        fecha: '2024-03-10T10:30:00',
        leido: false
      },
      {
        id: 2,
        remitente: 'Prof. Martínez',
        mensaje: 'Tu última tarea fue excelente',
        fecha: '2024-03-09T15:45:00',
        leido: true
      }
    ];

    const profesoresDemo = [
      { id: 1, nombre: 'Prof. García' },
      { id: 2, nombre: 'Prof. Martínez' }
    ];

    setMensajes(mensajesDemo);
    setProfesores(profesoresDemo);
  }, []);

  const enviarMensaje = (e) => {
    e.preventDefault();
    if (!destinatario || !nuevoMensaje) return;

    const mensaje = {
      id: Date.now(),
      remitente: 'Yo',
      destinatario,
      mensaje: nuevoMensaje,
      fecha: new Date().toISOString(),
      leido: true
    };

    setMensajes([mensaje, ...mensajes]);
    setNuevoMensaje('');
    setDestinatario('');
  };

  return (
    <div className="section-container">
      <h2>Mensajes</h2>
      
      <div className="mensajes-layout">
        <div className="mensajes-lista">
          {mensajes.map(mensaje => (
            <div 
              key={mensaje.id} 
              className={`mensaje-card ${!mensaje.leido ? 'no-leido' : ''}`}
            >
              <div className="mensaje-header">
                <h3>{mensaje.remitente}</h3>
                <span className="fecha">
                  {new Date(mensaje.fecha).toLocaleString()}
                </span>
              </div>
              <p className="mensaje-contenido">{mensaje.mensaje}</p>
              <div className="mensaje-actions">
                <button className="btn-icon">
                  <i className="fas fa-reply"></i>
                </button>
                <button className="btn-icon">
                  <i className="fas fa-trash"></i>
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="nuevo-mensaje">
          <h3>Nuevo Mensaje</h3>
          <form onSubmit={enviarMensaje}>
            <div className="form-group">
              <label>Para:</label>
              <select 
                value={destinatario}
                onChange={(e) => setDestinatario(e.target.value)}
                required
              >
                <option value="">Seleccionar profesor</option>
                {profesores.map(prof => (
                  <option key={prof.id} value={prof.nombre}>
                    {prof.nombre}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Mensaje:</label>
              <textarea
                value={nuevoMensaje}
                onChange={(e) => setNuevoMensaje(e.target.value)}
                placeholder="Escribe tu mensaje aquí..."
                required
              />
            </div>
            <button type="submit" className="btn-primary">
              Enviar Mensaje
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default MensajesEstudiante; 