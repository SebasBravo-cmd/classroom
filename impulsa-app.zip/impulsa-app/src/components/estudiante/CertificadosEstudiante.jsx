import React, { useState, useEffect } from 'react';

const CertificadosEstudiante = () => {
  const [certificados, setCertificados] = useState([]);
  const [cursosCompletados, setCursosCompletados] = useState([]);

  useEffect(() => {
    // Simular carga de certificados y cursos completados
    const certificadosDemo = [
      {
        id: 1,
        curso: 'Desarrollo Web Avanzado',
        fecha: '2024-02-15',
        calificacion: 95,
        instructor: 'Prof. García',
        codigo: 'CERT-2024-001'
      }
    ];

    const cursosCompletadosDemo = [
      {
        id: 1,
        nombre: 'Introducción a React',
        progreso: 100,
        fecha_completado: '2024-03-10',
        certificado_disponible: true
      }
    ];

    setCertificados(certificadosDemo);
    setCursosCompletados(cursosCompletadosDemo);
  }, []);

  const descargarCertificado = (certificado) => {
    // Lógica para descargar certificado
    console.log(`Descargando certificado: ${certificado.codigo}`);
  };

  const solicitarCertificado = (curso) => {
    // Lógica para solicitar nuevo certificado
    console.log(`Solicitando certificado para: ${curso.nombre}`);
  };

  return (
    <div className="section-container">
      <h2>Mis Certificados</h2>

      <div className="certificados-grid">
        <div className="certificados-obtenidos">
          <h3>Certificados Obtenidos</h3>
          {certificados.map(certificado => (
            <div key={certificado.id} className="certificado-card">
              <div className="certificado-header">
                <i className="fas fa-certificate"></i>
                <h4>{certificado.curso}</h4>
              </div>
              <div className="certificado-info">
                <p><strong>Instructor:</strong> {certificado.instructor}</p>
                <p><strong>Fecha:</strong> {new Date(certificado.fecha).toLocaleDateString()}</p>
                <p><strong>Calificación:</strong> {certificado.calificacion}%</p>
                <p><strong>Código:</strong> {certificado.codigo}</p>
              </div>
              <div className="certificado-actions">
                <button 
                  className="btn-primary"
                  onClick={() => descargarCertificado(certificado)}
                >
                  <i className="fas fa-download"></i> Descargar
                </button>
                <button className="btn-secondary">
                  <i className="fas fa-share"></i> Compartir
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="cursos-completados">
          <h3>Cursos Completados</h3>
          {cursosCompletados.map(curso => (
            <div key={curso.id} className="curso-completado-card">
              <div className="curso-info">
                <h4>{curso.nombre}</h4>
                <p>Completado: {new Date(curso.fecha_completado).toLocaleDateString()}</p>
              </div>
              {curso.certificado_disponible ? (
                <button 
                  className="btn-primary"
                  onClick={() => solicitarCertificado(curso)}
                >
                  Solicitar Certificado
                </button>
              ) : (
                <span className="badge pendiente">En proceso</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CertificadosEstudiante; 