import React from 'react';
import '../../styles/components/EstudianteDashboard.css';

const ProgresoEstudiante = () => {
  const progresoTotal = 65;
  const modulos = [
    {
      nombre: 'Introducción',
      progreso: 100,
      actividades: [
        { nombre: 'Video introductorio', completado: true, tipo: 'video' },
        { nombre: 'Quiz inicial', completado: true, tipo: 'quiz' }
      ]
    },
    {
      nombre: 'Fundamentos',
      progreso: 60,
      actividades: [
        { nombre: 'Lectura básica', completado: true, tipo: 'lectura' },
        { nombre: 'Ejercicio práctico', completado: false, tipo: 'ejercicio' },
        { nombre: 'Quiz fundamentos', completado: false, tipo: 'quiz' }
      ]
    }
  ];

  return (
    <div className="estudiante-dashboard">
      <div className="progreso-principal">
        <div className="circulo-progreso">
          <svg viewBox="0 0 36 36" className="circular-chart">
            <path
              d="M18 2.0845
                a 15.9155 15.9155 0 0 1 0 31.831
                a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="#eee"
              strokeWidth="2"
            />
            <path
              d="M18 2.0845
                a 15.9155 15.9155 0 0 1 0 31.831
                a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="var(--sidebar-bg)"
              strokeWidth="2"
              strokeDasharray={`${progresoTotal}, 100`}
            />
          </svg>
          <div className="porcentaje-texto">{progresoTotal}%</div>
        </div>
      </div>

      <div className="modulos-container">
        <div className="modulo-header">
          <h2 className="modulo-titulo">Progreso por Módulos</h2>
        </div>
        
        {modulos.map((modulo, index) => (
          <div key={index} className="modulo-item">
            <div className="modulo-nombre">
              <span>{modulo.nombre}</span>
              <span>{modulo.progreso}%</span>
            </div>
            <div className="modulo-progreso">
              <div 
                className="progreso-barra" 
                style={{ width: `${modulo.progreso}%` }}
              />
            </div>
            <div className="actividades-lista">
              {modulo.actividades.map((actividad, actIndex) => (
                <div key={actIndex} className="actividad-item">
                  <div className={`actividad-icono ${actividad.completado ? 'actividad-completada' : ''}`}>
                    <i className={`fas fa-${getIconoActividad(actividad.tipo)}`} />
                  </div>
                  <span className="actividad-nombre">{actividad.nombre}</span>
                  <span className="actividad-estado">
                    {actividad.completado ? (
                      <i className="fas fa-check-circle text-success" />
                    ) : (
                      <i className="fas fa-circle text-muted" />
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const getIconoActividad = (tipo) => {
  switch (tipo) {
    case 'video': return 'play-circle';
    case 'quiz': return 'question-circle';
    case 'lectura': return 'book';
    case 'ejercicio': return 'pencil-alt';
    default: return 'circle';
  }
};

export default ProgresoEstudiante; 