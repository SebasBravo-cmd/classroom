import React, { useState, useEffect } from 'react';

const MaterialesEstudiante = ({ curso, onVolver }) => {
  const [materiales, setMateriales] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const cargarMateriales = async () => {
      try {
        // Simular carga de materiales del curso específico
        const materialesDemo = {
          modulos: [
            {
              id: 1,
              titulo: "Módulo 1: Introducción",
              materiales: [
                { id: 1, titulo: "Guía del curso", tipo: "documento", formato: "pdf", url: "/docs/guia.pdf" },
                { id: 2, titulo: "Video introductorio", tipo: "video", duracion: "10:30", url: "/videos/intro.mp4" },
                { id: 3, titulo: "Presentación inicial", tipo: "presentacion", slides: 25, url: "/slides/intro.pptx" }
              ]
            },
            {
              id: 2,
              titulo: "Módulo 2: Fundamentos",
              materiales: [
                { id: 4, titulo: "Manual de ejercicios", tipo: "documento", formato: "pdf", url: "/docs/ejercicios.pdf" },
                { id: 5, titulo: "Clase grabada", tipo: "video", duracion: "45:20", url: "/videos/clase1.mp4" }
              ]
            }
          ]
        };

        setMateriales(materialesDemo);
        setLoading(false);
      } catch (error) {
        console.error('Error al cargar materiales:', error);
        setLoading(false);
      }
    };

    cargarMateriales();
  }, [curso]);

  const getIconoMaterial = (tipo) => {
    switch (tipo) {
      case 'documento': return 'fas fa-file-pdf';
      case 'video': return 'fas fa-video';
      case 'presentacion': return 'fas fa-file-powerpoint';
      default: return 'fas fa-file';
    }
  };

  if (loading) return <div className="loading">Cargando materiales...</div>;

  return (
    <div className="curso-overlay">
      <div className="curso-content">
        <button className="btn-volver" onClick={onVolver}>
          <i className="fas fa-arrow-left"></i>
          Volver al dashboard
        </button>

        <div className="curso-header">
          <h2>{curso.nombre}</h2>
          <span className="curso-tipo">{curso.categoria}</span>
        </div>

        <div className="curso-detalles">
          <div className="curso-info">
            <p><i className="fas fa-clock"></i> Duración: {curso.duracion}</p>
            <p><i className="fas fa-book"></i> {curso.modulos} módulos</p>
            <p><i className="fas fa-user-graduate"></i> Profesor: {curso.profesor}</p>
          </div>

          <div className="progreso-container">
            <div className="progreso-info">
              <span>Progreso del curso</span>
              <span>30%</span>
            </div>
            <div className="progreso-barra">
              <div className="progreso-completado" style={{ width: '30%' }}></div>
            </div>
          </div>

          {materiales.modulos.map(modulo => (
            <div key={modulo.id} className="material-seccion">
              <h4>
                <i className="fas fa-folder"></i>
                {modulo.titulo}
              </h4>
              <ul className="material-lista">
                {modulo.materiales.map(material => (
                  <li key={material.id}>
                    <i className={getIconoMaterial(material.tipo)}></i>
                    <span>{material.titulo}</span>
                    {material.duracion && <span>{material.duracion}</span>}
                    {material.slides && <span>{material.slides} diapositivas</span>}
                    {material.tipo === 'video' ? (
                      <button className="btn-ver">
                        <i className="fas fa-play"></i> Ver
                      </button>
                    ) : (
                      <button className="btn-descargar">
                        <i className="fas fa-download"></i> Descargar
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MaterialesEstudiante; 