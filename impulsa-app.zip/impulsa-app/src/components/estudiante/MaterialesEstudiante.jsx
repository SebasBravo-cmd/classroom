import React, { useState, useEffect } from 'react';

const MaterialesEstudiante = () => {
  const [materiales, setMateriales] = useState({
    documentos: [],
    videos: [],
    presentaciones: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simular carga de materiales
    const cargarMateriales = async () => {
      try {
        // Aquí iría la llamada a tu API
        const materialesDemo = {
          documentos: [
            { id: 1, titulo: 'Guía de estudio', tipo: 'pdf', url: '/docs/guia.pdf' },
            { id: 2, titulo: 'Lecturas complementarias', tipo: 'pdf', url: '/docs/lecturas.pdf' }
          ],
          videos: [
            { id: 1, titulo: 'Introducción al curso', duracion: '10:30', url: '/videos/intro.mp4' },
            { id: 2, titulo: 'Tutorial práctico', duracion: '15:45', url: '/videos/tutorial.mp4' }
          ],
          presentaciones: [
            { id: 1, titulo: 'Módulo 1', slides: 25, url: '/slides/mod1.pptx' },
            { id: 2, titulo: 'Módulo 2', slides: 30, url: '/slides/mod2.pptx' }
          ]
        };
        setMateriales(materialesDemo);
        setLoading(false);
      } catch (error) {
        console.error('Error al cargar materiales:', error);
        setLoading(false);
      }
    };

    cargarMateriales();
  }, []);

  const renderMaterialCard = (material, tipo) => (
    <div key={material.id} className="material-card">
      <div className="material-icon">
        {tipo === 'documentos' && <i className="fas fa-file-pdf"></i>}
        {tipo === 'videos' && <i className="fas fa-video"></i>}
        {tipo === 'presentaciones' && <i className="fas fa-file-powerpoint"></i>}
      </div>
      <div className="material-info">
        <h3>{material.titulo}</h3>
        {tipo === 'videos' && <span className="duracion">{material.duracion}</span>}
        {tipo === 'presentaciones' && <span className="slides">{material.slides} diapositivas</span>}
      </div>
      <a href={material.url} className="material-download" download>
        <i className="fas fa-download"></i>
      </a>
    </div>
  );

  if (loading) return <div className="loading">Cargando materiales...</div>;

  return (
    <div className="section-container">
      <h2>Materiales del Curso</h2>
      
      <section className="material-section">
        <h3>Documentos</h3>
        <div className="materials-grid">
          {materiales.documentos.map(doc => renderMaterialCard(doc, 'documentos'))}
        </div>
      </section>

      <section className="material-section">
        <h3>Videos</h3>
        <div className="materials-grid">
          {materiales.videos.map(video => renderMaterialCard(video, 'videos'))}
        </div>
      </section>

      <section className="material-section">
        <h3>Presentaciones</h3>
        <div className="materials-grid">
          {materiales.presentaciones.map(pres => renderMaterialCard(pres, 'presentaciones'))}
        </div>
      </section>
    </div>
  );
};

export default MaterialesEstudiante; 