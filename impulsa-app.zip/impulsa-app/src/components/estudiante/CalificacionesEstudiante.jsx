import React, { useState, useEffect } from 'react';

const CalificacionesEstudiante = () => {
  const [calificaciones, setCalificaciones] = useState([]);
  const [promedioGeneral, setPromedioGeneral] = useState(0);

  useEffect(() => {
    // Simular carga de calificaciones
    const calificacionesDemo = [
      {
        id: 1,
        actividad: 'Examen Parcial 1',
        tipo: 'examen',
        calificacion: 85,
        retroalimentacion: 'Buen trabajo en general, mejorar conceptos básicos',
        fecha: '2024-02-15'
      },
      {
        id: 2,
        actividad: 'Proyecto Grupal',
        tipo: 'proyecto',
        calificacion: 92,
        retroalimentacion: 'Excelente trabajo en equipo',
        fecha: '2024-03-01'
      }
    ];
    
    setCalificaciones(calificacionesDemo);
    
    // Calcular promedio
    const promedio = calificacionesDemo.reduce((acc, cal) => acc + cal.calificacion, 0) / calificacionesDemo.length;
    setPromedioGeneral(promedio);
  }, []);

  return (
    <div className="section-container">
      <div className="calificaciones-header">
        <h2>Mis Calificaciones</h2>
        <div className="promedio-general">
          <span>Promedio General:</span>
          <strong>{promedioGeneral.toFixed(2)}</strong>
        </div>
      </div>

      <div className="calificaciones-grid">
        {calificaciones.map(cal => (
          <div key={cal.id} className="calificacion-card">
            <div className="calificacion-header">
              <h3>{cal.actividad}</h3>
              <span className={`tipo-badge ${cal.tipo}`}>
                {cal.tipo}
              </span>
            </div>
            <div className="calificacion-body">
              <div className="calificacion-valor">
                <span>Calificación:</span>
                <strong>{cal.calificacion}</strong>
              </div>
              <div className="retroalimentacion">
                <h4>Retroalimentación:</h4>
                <p>{cal.retroalimentacion}</p>
              </div>
            </div>
            <div className="calificacion-footer">
              <span className="fecha">
                Fecha: {new Date(cal.fecha).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalificacionesEstudiante; 