import React, { useState, useEffect } from 'react';

const EnrolarEstudiantes = () => {
  const [estudiantes, setEstudiantes] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [estudianteSeleccionado, setEstudianteSeleccionado] = useState('');
  const [cursoSeleccionado, setCursoSeleccionado] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = () => {
    // Cargar estudiantes y cursos del localStorage
    const cargarEstudiantes = () => {
      const users = Object.keys(localStorage)
        .filter(key => {
          try {
            const user = JSON.parse(localStorage.getItem(key));
            return user.role === 'estudiante';
          } catch (error) {
            return false;
          }
        })
        .map(key => ({ email: key, ...JSON.parse(localStorage.getItem(key)) }));
      setEstudiantes(users);
    };

    const cargarCursos = () => {
      const cursosGuardados = JSON.parse(localStorage.getItem('cursos')) || [];
      setCursos(cursosGuardados);
    };

    cargarEstudiantes();
    cargarCursos();
  };

  const limpiarFormulario = () => {
    setEstudianteSeleccionado('');
    setCursoSeleccionado('');
  };

  const mostrarMensaje = (texto, esError = false) => {
    setMessage({ texto, tipo: esError ? 'error' : 'success' });
    setTimeout(() => setMessage(''), 3000); // El mensaje desaparece después de 3 segundos
  };

  const enrolarEstudiante = (e) => {
    e.preventDefault();
    
    if (!estudianteSeleccionado || !cursoSeleccionado) {
      mostrarMensaje('Por favor, selecciona un estudiante y un curso', true);
      return;
    }

    try {
      // Obtener datos actuales del estudiante
      const estudiante = JSON.parse(localStorage.getItem(estudianteSeleccionado));
      
      // Inicializar array de cursos inscritos si no existe
      if (!estudiante.cursosInscritos) {
        estudiante.cursosInscritos = [];
      }

      const cursoId = parseInt(cursoSeleccionado);
      
      // Verificar si ya está inscrito
      if (!estudiante.cursosInscritos.includes(cursoId)) {
        // Agregar el nuevo curso
        estudiante.cursosInscritos.push(cursoId);
        
        // Guardar los cambios
        localStorage.setItem(estudianteSeleccionado, JSON.stringify(estudiante));
        
        // Actualizar la lista de cursos
        cargarDatos();
        
        mostrarMensaje('Estudiante enrolado exitosamente');
        limpiarFormulario();
      } else {
        mostrarMensaje('El estudiante ya está inscrito en este curso', true);
      }
    } catch (error) {
      console.error('Error al enrolar:', error);
      mostrarMensaje('Error al enrolar al estudiante', true);
    }
  };

  return (
    <div className="enrolar-container">
      <h2>Enrolar Estudiantes</h2>
      {message && (
        <div className={`message ${message.tipo}`}>
          {message.texto}
        </div>
      )}
      <form onSubmit={enrolarEstudiante}>
        <div className="form-group">
          <label htmlFor="estudiante">Seleccionar Estudiante:</label>
          <select
            id="estudiante"
            value={estudianteSeleccionado}
            onChange={(e) => setEstudianteSeleccionado(e.target.value)}
            required
          >
            <option value="">Seleccione un estudiante</option>
            {estudiantes.map(estudiante => (
              <option key={estudiante.email} value={estudiante.email}>
                {estudiante.nombre} {estudiante.apellido} ({estudiante.email})
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="curso">Seleccionar Curso:</label>
          <select
            id="curso"
            value={cursoSeleccionado}
            onChange={(e) => setCursoSeleccionado(e.target.value)}
            required
          >
            <option value="">Seleccione un curso</option>
            {cursos.map(curso => (
              <option key={curso.id} value={curso.id}>{curso.nombre}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn-enrolar">Enrolar Estudiante</button>
      </form>
    </div>
  );
};

export default EnrolarEstudiantes; 