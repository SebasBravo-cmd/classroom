import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./components/Login";
import Registrar from "./components/Registrar";
import EstudianteDashboard from "./components/dashboards/EstudianteDashboard";
import ProfesorDashboard from "./components/dashboards/ProfesorDashboard";
import ClienteDashboard from "./components/dashboards/ClienteDashboard";
import AdminDashboard from "./components/dashboards/AdminDashboard";
import PrivateRoute from "./components/PrivateRoute";
import CalificacionesEstudiante from './components/estudiante/CalificacionesEstudiante';
import TareasEstudiante from './components/estudiante/TareasEstudiante';
import MensajesEstudiante from './components/estudiante/MensajesEstudiante';
import ProgresoEstudiante from './components/estudiante/ProgresoEstudiante';
import GestionCursos from './components/profesor/GestionCursos';
import GestionContenidos from './components/profesor/GestionContenidos';
import GestionEstudiantes from './components/profesor/GestionEstudiantes';
import ConfiguracionCursos from './components/profesor/ConfiguracionCursos';
import BienvenidaProfesor from './components/profesor/BienvenidaProfesor';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/registrar" element={<Registrar />} />
        <Route 
          path="/dashboard/estudiante/*" 
          element={
            <PrivateRoute>
              <EstudianteDashboard>
                <Routes>
                  <Route path="/" element={<ProgresoEstudiante />} />
                  <Route path="calificaciones" element={<CalificacionesEstudiante />} />
                  <Route path="tareas" element={<TareasEstudiante />} />
                  <Route path="mensajes" element={<MensajesEstudiante />} />
                </Routes>
              </EstudianteDashboard>
            </PrivateRoute>
          } 
        />
        <Route 
          path="/dashboard/profesor" 
          element={
            <PrivateRoute>
              <ProfesorDashboard />
            </PrivateRoute>
          } 
        />
        <Route 
          path="/dashboard/cliente" 
          element={
            <PrivateRoute>
              <ClienteDashboard />
            </PrivateRoute>
          } 
        />
        <Route 
          path="/dashboard/admin" 
          element={
            <PrivateRoute>
              <AdminDashboard />
            </PrivateRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
};

export default App;
