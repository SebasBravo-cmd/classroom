import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/login.css';

const RecuperarPassword = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Solicitud de recuperación para:', email);
    // Aquí irá la lógica para enviar el correo de recuperación
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Recuperar Contraseña</h2>
        
        <div className="form-group">
          <label htmlFor="email">Correo Electrónico</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="login-button">
          Enviar Instrucciones
        </button>

        <div className="back-to-login">
          <Link to="/login">Volver al inicio de sesión</Link>
        </div>
      </form>
    </div>
  );
};

export default RecuperarPassword; 