import React from 'react';
import { useAuth } from '../../context/AuthContext';
import '../../styles/dashboard.css';

function EstudianteDashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="dashboard">
      <nav className="dashboard-nav">
        <h1>Panel de Estudiante</h1>
        <div className="user-info">
          <span>Bienvenido, {user.name}</span>
          <button onClick={logout}>Cerrar Sesión</button>
        </div>
      </nav>
      <div className="dashboard-content">
        <div className="dashboard-grid">
          <div className="dashboard-card">
            <h3>Mis Cursos</h3>
            <p className="number">4</p>
          </div>
          <div className="dashboard-card">
            <h3>Tareas Pendientes</h3>
            <p className="number">3</p>
          </div>
          <div className="dashboard-card">
            <h3>Promedio General</h3>
            <p className="number">8.5</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EstudianteDashboard; 