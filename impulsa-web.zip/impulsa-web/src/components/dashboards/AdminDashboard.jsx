import React from 'react';
import { useAuth } from '../../context/AuthContext';
import '../../styles/dashboard.css';

function AdminDashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="dashboard">
      <nav className="dashboard-nav">
        <h1>Panel de Administrador</h1>
        <div className="user-info">
          <span>Bienvenido, {user.name}</span>
          <button onClick={logout}>Cerrar Sesión</button>
        </div>
      </nav>
      <div className="dashboard-content">
        <div className="dashboard-grid">
          <div className="dashboard-card">
            <h3>Usuarios Totales</h3>
            <p className="number">1,234</p>
          </div>
          <div className="dashboard-card">
            <h3>Profesores</h3>
            <p className="number">45</p>
          </div>
          <div className="dashboard-card">
            <h3>Estudiantes</h3>
            <p className="number">890</p>
          </div>
          <div className="dashboard-card">
            <h3>Clientes</h3>
            <p className="number">299</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard; 