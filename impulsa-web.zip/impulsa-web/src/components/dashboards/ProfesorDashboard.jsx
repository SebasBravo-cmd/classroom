import React from 'react';
import { useAuth } from '../../context/AuthContext';
import '../../styles/dashboard.css';

function ProfesorDashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="dashboard">
      <nav className="dashboard-nav">
        <h1>Panel de Profesor</h1>
        <div className="user-info">
          <span>Bienvenido, {user.name}</span>
          <button onClick={logout}>Cerrar Sesión</button>
        </div>
      </nav>
      <div className="dashboard-content">
        <div className="dashboard-grid">
          <div className="dashboard-card">
            <h3>Mis Cursos</h3>
            <p className="number">5</p>
          </div>
          <div className="dashboard-card">
            <h3>Estudiantes Activos</h3>
            <p className="number">120</p>
          </div>
          <div className="dashboard-card">
            <h3>Tareas Pendientes</h3>
            <p className="number">8</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProfesorDashboard; 