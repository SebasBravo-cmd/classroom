import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './components/Login';
import AdminDashboard from './components/dashboards/AdminDashboard';
import ProfesorDashboard from './components/dashboards/ProfesorDashboard';
import EstudianteDashboard from './components/dashboards/EstudianteDashboard';
import ClienteDashboard from './components/dashboards/ClienteDashboard';
import RecuperarPassword from './components/RecuperarPassword';
import Registro from './components/Registro';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/recuperar-password" element={<RecuperarPassword />} />
          <Route path="/registro" element={<Registro />} />
          
          <Route
            path="/dashboard/admin"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/dashboard/profesor"
            element={
              <ProtectedRoute allowedRoles={['profesor']}>
                <ProfesorDashboard />
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/dashboard/estudiante"
            element={
              <ProtectedRoute allowedRoles={['estudiante']}>
                <EstudianteDashboard />
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/dashboard/cliente"
            element={
              <ProtectedRoute allowedRoles={['cliente']}>
                <ClienteDashboard />
              </ProtectedRoute>
            }
          />

          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;